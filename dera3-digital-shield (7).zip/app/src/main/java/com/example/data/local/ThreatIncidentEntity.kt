package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.data.model.PhishingCategory
import com.example.data.model.ShieldId
import com.example.data.model.ThreatSeverity

enum class IncidentActionTaken(val isResolvedByDefault: Boolean) {
    DETECTED_LOGGED(false),
    BLOCKED_AUTO(true),
    USER_INSPECTED(true),
    SHIELD_SECURED(true),
    USER_DISMISSED(true);

    companion object {
        fun fromRaw(raw: String?): IncidentActionTaken =
            entries.firstOrNull { it.name == raw } ?: DETECTED_LOGGED
    }
}

@Entity(
    tableName = "threat_incidents",
    indices = [
        Index(value = ["userId", "detectedAtMillis"]),
        Index(value = ["userId", "sourceKey"]),
    ],
)
data class ThreatIncidentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val userId: String,
    val sourceKey: String = "",
    val shieldKey: String,
    val category: String = PhishingCategory.LINK_PHISHING.name,
    val severity: String = ThreatSeverity.HIGH.name,
    val indicator: String = "",
    val titleAr: String = "",
    val titleEn: String = "",
    val messageAr: String = "",
    val messageEn: String = "",
    val actionTaken: String = IncidentActionTaken.DETECTED_LOGGED.name,
    val actionNoteAr: String = "",
    val actionNoteEn: String = "",
    val resolved: Boolean = false,
    val detectedAtMillis: Long = System.currentTimeMillis(),
    val actionUpdatedAtMillis: Long = System.currentTimeMillis(),
) {
    val parsedCategory: PhishingCategory
        get() = PhishingCategory.fromRaw(category)

    val parsedSeverity: ThreatSeverity
        get() = ThreatSeverity.fromRaw(severity)

    val parsedAction: IncidentActionTaken
        get() = IncidentActionTaken.fromRaw(actionTaken)

    val targetShield: ShieldId
        get() = ShieldId.entries.firstOrNull { it.key == shieldKey } ?: parsedCategory.targetShield
}
