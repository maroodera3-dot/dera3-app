package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ThreatIncidentDao {
    @Query("SELECT * FROM threat_incidents WHERE userId = :userId ORDER BY detectedAtMillis DESC, id DESC")
    fun observeIncidentsForUser(userId: String): Flow<List<ThreatIncidentEntity>>

    @Query("SELECT * FROM threat_incidents WHERE userId = :userId AND sourceKey = :sourceKey LIMIT 1")
    suspend fun findBySourceKey(userId: String, sourceKey: String): ThreatIncidentEntity?

    @Query("SELECT * FROM threat_incidents WHERE id = :id LIMIT 1")
    suspend fun getIncidentById(id: Long): ThreatIncidentEntity?

    @Query(
        "SELECT * FROM threat_incidents " +
            "WHERE userId = :userId AND detectedAtMillis >= :sinceMillis AND detectedAtMillis < :untilMillis " +
            "ORDER BY detectedAtMillis DESC, id DESC"
    )
    suspend fun getIncidentsInRange(
        userId: String,
        sinceMillis: Long,
        untilMillis: Long,
    ): List<ThreatIncidentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIncident(incident: ThreatIncidentEntity): Long

    @Query(
        "UPDATE threat_incidents " +
            "SET actionTaken = :actionTaken, actionNoteAr = :noteAr, actionNoteEn = :noteEn, " +
            "resolved = :resolved, actionUpdatedAtMillis = :updatedAtMillis " +
            "WHERE id = :id"
    )
    suspend fun updateIncidentAction(
        id: Long,
        actionTaken: String,
        noteAr: String,
        noteEn: String,
        resolved: Boolean,
        updatedAtMillis: Long,
    )

    @Query(
        "UPDATE threat_incidents " +
            "SET actionTaken = :actionTaken, actionNoteAr = :noteAr, actionNoteEn = :noteEn, " +
            "resolved = 1, actionUpdatedAtMillis = :updatedAtMillis " +
            "WHERE userId = :userId AND resolved = 0"
    )
    suspend fun markAllResolved(
        userId: String,
        actionTaken: String,
        noteAr: String,
        noteEn: String,
        updatedAtMillis: Long,
    )

    @Query("DELETE FROM threat_incidents WHERE id = :id")
    suspend fun deleteIncidentById(id: Long)

    @Query("DELETE FROM threat_incidents WHERE userId = :userId")
    suspend fun clearHistoryForUser(userId: String)
}
