package com.example.data.local

import com.example.data.model.PhishingCategory
import com.example.data.model.PhishingNotificationItem
import com.example.data.model.ShieldId
import com.example.data.model.ThreatSeverity
import kotlinx.coroutines.flow.Flow

class ThreatHistoryRepository(
    private val dao: ThreatIncidentDao,
) {
    fun observeHistory(userId: String): Flow<List<ThreatIncidentEntity>> =
        dao.observeIncidentsForUser(userId)

    suspend fun recordDetectedIncident(
        userId: String,
        shieldKey: String,
        category: PhishingCategory,
        severity: ThreatSeverity,
        indicator: String,
        titleAr: String,
        titleEn: String,
        messageAr: String,
        messageEn: String,
        sourceKey: String = "",
        detectedAtMillis: Long = System.currentTimeMillis(),
    ): Long = recordDetectedIncidentEntity(
        userId = userId,
        shieldKey = shieldKey,
        category = category,
        severity = severity,
        indicator = indicator,
        titleAr = titleAr,
        titleEn = titleEn,
        messageAr = messageAr,
        messageEn = messageEn,
        sourceKey = sourceKey,
        detectedAtMillis = detectedAtMillis,
    ).id

    suspend fun recordDetectedIncidentEntity(
        userId: String,
        shieldKey: String,
        category: PhishingCategory,
        severity: ThreatSeverity,
        indicator: String,
        titleAr: String,
        titleEn: String,
        messageAr: String,
        messageEn: String,
        sourceKey: String = "",
        detectedAtMillis: Long = System.currentTimeMillis(),
    ): ThreatIncidentEntity {
        val isAutoBlocked = shieldKey == ShieldId.SAFE_BROWSER.key
        val initialAction = if (isAutoBlocked) {
            IncidentActionTaken.BLOCKED_AUTO
        } else {
            IncidentActionTaken.DETECTED_LOGGED
        }
        val noteAr = if (isAutoBlocked) {
            "حظر تلقائي بواسطة المتصفح الآمن"
        } else {
            "تم رصد التهديد وتسجيله محلياً"
        }
        val noteEn = if (isAutoBlocked) {
            "Automatically blocked by Safe Browser"
        } else {
            "Threat detected and logged locally"
        }

        val entity = ThreatIncidentEntity(
            userId = userId,
            sourceKey = sourceKey.take(120),
            shieldKey = shieldKey.take(40),
            category = category.name,
            severity = severity.name,
            indicator = indicator.trim().take(160),
            titleAr = titleAr.trim().take(140),
            titleEn = titleEn.trim().take(140),
            messageAr = messageAr.trim().take(400),
            messageEn = messageEn.trim().take(400),
            actionTaken = initialAction.name,
            actionNoteAr = noteAr,
            actionNoteEn = noteEn,
            resolved = initialAction.isResolvedByDefault,
            detectedAtMillis = detectedAtMillis,
            actionUpdatedAtMillis = detectedAtMillis,
        )
        val insertedId = dao.insertIncident(entity)
        return entity.copy(id = insertedId)
    }

    suspend fun ensureRemoteAlertInHistory(
        userId: String,
        item: PhishingNotificationItem,
        nowMillis: Long = System.currentTimeMillis(),
    ): ThreatIncidentEntity {
        val sourceKey = "${if (item.isPersonalDetection) "personal" else "global"}_${item.id}"
        val existing = dao.findBySourceKey(userId, sourceKey)
        if (existing != null) return existing
        val detectedMs = if (item.timestampSeconds > 0L) item.timestampSeconds * 1000L else nowMillis
        val action = when {
            item.dismissed -> IncidentActionTaken.USER_DISMISSED
            item.read -> IncidentActionTaken.USER_INSPECTED
            else -> IncidentActionTaken.DETECTED_LOGGED
        }
        val entity = ThreatIncidentEntity(
            userId = userId,
            sourceKey = sourceKey,
            shieldKey = item.targetShield.key,
            category = item.category.name,
            severity = item.severity.name,
            indicator = item.indicator.trim().take(160),
            titleAr = item.titleAr.trim().take(140),
            titleEn = item.titleEn.trim().take(140),
            messageAr = item.messageAr.trim().take(400),
            messageEn = item.messageEn.trim().take(400),
            actionTaken = action.name,
            actionNoteAr = if (action == IncidentActionTaken.DETECTED_LOGGED) {
                "تنبيه أمني مسجل محلياً — بانتظار المراجعة"
            } else {
                "تمت مزامنة حالة التنبيه"
            },
            actionNoteEn = if (action == IncidentActionTaken.DETECTED_LOGGED) {
                "Security alert saved locally — awaiting review"
            } else {
                "Alert status synced locally"
            },
            resolved = action.isResolvedByDefault,
            detectedAtMillis = detectedMs,
            actionUpdatedAtMillis = nowMillis,
        )
        val insertedId = dao.insertIncident(entity)
        return entity.copy(id = insertedId)
    }

    suspend fun getIncidentById(id: Long): ThreatIncidentEntity? = dao.getIncidentById(id)

    suspend fun getIncidentsInRange(
        userId: String,
        sinceMillis: Long,
        untilMillis: Long,
    ): List<ThreatIncidentEntity> = dao.getIncidentsInRange(
        userId = userId,
        sinceMillis = sinceMillis,
        untilMillis = untilMillis,
    )

    suspend fun recordNotificationAction(
        userId: String,
        item: PhishingNotificationItem,
        read: Boolean,
        dismissed: Boolean,
        nowMillis: Long = System.currentTimeMillis(),
    ) {
        val action = when {
            dismissed -> IncidentActionTaken.USER_DISMISSED
            read -> IncidentActionTaken.USER_INSPECTED
            else -> IncidentActionTaken.DETECTED_LOGGED
        }
        val noteAr = when (action) {
            IncidentActionTaken.USER_DISMISSED -> "تم تجاهل التنبيه ووسمه كآمن"
            IncidentActionTaken.USER_INSPECTED -> "تمت مراجعة التنبيه وفحصه"
            else -> "تم تسجيل التنبيه في السجل المحلي"
        }
        val noteEn = when (action) {
            IncidentActionTaken.USER_DISMISSED -> "Dismissed and marked safe by user"
            IncidentActionTaken.USER_INSPECTED -> "Reviewed and inspected by user"
            else -> "Logged in local incident history"
        }

        val sourceKey = "${if (item.isPersonalDetection) "personal" else "global"}_${item.id}"
        val existing = dao.findBySourceKey(userId, sourceKey)
        if (existing != null) {
            dao.updateIncidentAction(
                id = existing.id,
                actionTaken = action.name,
                noteAr = noteAr,
                noteEn = noteEn,
                resolved = action.isResolvedByDefault,
                updatedAtMillis = nowMillis,
            )
        } else {
            val detectedMs = if (item.timestampSeconds > 0L) item.timestampSeconds * 1000L else nowMillis
            dao.insertIncident(
                ThreatIncidentEntity(
                    userId = userId,
                    sourceKey = sourceKey,
                    shieldKey = item.targetShield.key,
                    category = item.category.name,
                    severity = item.severity.name,
                    indicator = item.indicator.trim().take(160),
                    titleAr = item.titleAr.trim().take(140),
                    titleEn = item.titleEn.trim().take(140),
                    messageAr = item.messageAr.trim().take(400),
                    messageEn = item.messageEn.trim().take(400),
                    actionTaken = action.name,
                    actionNoteAr = noteAr,
                    actionNoteEn = noteEn,
                    resolved = action.isResolvedByDefault,
                    detectedAtMillis = detectedMs,
                    actionUpdatedAtMillis = nowMillis,
                )
            )
        }
    }

    suspend fun updateActionTaken(
        incidentId: Long,
        action: IncidentActionTaken,
        resolved: Boolean = action.isResolvedByDefault,
        nowMillis: Long = System.currentTimeMillis(),
    ) {
        val (noteAr, noteEn) = when (action) {
            IncidentActionTaken.BLOCKED_AUTO ->
                "تم حظر التهديد تلقائياً" to "Automatically blocked by protection engine"
            IncidentActionTaken.USER_INSPECTED ->
                "تم فحص الحادث ومراجعته" to "Incident reviewed & inspected"
            IncidentActionTaken.SHIELD_SECURED ->
                "تم تأمين الدرع المرتبط بالتهديد" to "Associated security shield secured"
            IncidentActionTaken.USER_DISMISSED ->
                "تم تجاهل التهديد أو اعتباره آمناً" to "Dismissed or marked safe by user"
            IncidentActionTaken.DETECTED_LOGGED ->
                "قيد المتابعة والمراجعة" to "Logged & awaiting review"
        }
        dao.updateIncidentAction(
            id = incidentId,
            actionTaken = action.name,
            noteAr = noteAr,
            noteEn = noteEn,
            resolved = resolved,
            updatedAtMillis = nowMillis,
        )
    }

    suspend fun markAllResolved(userId: String, nowMillis: Long = System.currentTimeMillis()) {
        dao.markAllResolved(
            userId = userId,
            actionTaken = IncidentActionTaken.USER_INSPECTED.name,
            noteAr = "تمت مراجعة جميع الحوادث المفتوحة",
            noteEn = "All open incidents marked reviewed",
            updatedAtMillis = nowMillis,
        )
    }

    suspend fun deleteIncident(incidentId: Long) = dao.deleteIncidentById(incidentId)

    suspend fun clearHistoryForUser(userId: String) = dao.clearHistoryForUser(userId)
}
