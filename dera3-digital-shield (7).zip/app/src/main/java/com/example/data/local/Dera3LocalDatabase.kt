package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ThreatIncidentEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class Dera3LocalDatabase : RoomDatabase() {
    abstract fun threatIncidentDao(): ThreatIncidentDao

    companion object {
        private const val DATABASE_NAME = "dera3_local_threats.db"

        @Volatile
        private var instance: Dera3LocalDatabase? = null

        fun getInstance(context: Context): Dera3LocalDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    Dera3LocalDatabase::class.java,
                    DATABASE_NAME,
                ).build().also { instance = it }
            }
        }
    }
}
