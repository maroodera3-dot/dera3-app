package com.example.domain

import androidx.compose.runtime.Immutable
import com.example.data.local.IncidentActionTaken
import com.example.data.local.ThreatIncidentEntity
import com.example.data.model.PhishingCategory
import com.example.data.model.ThreatSeverity
import com.example.localization.AppLanguage
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.roundToInt

@Immutable
data class WeeklyRoomWindow(
    val sinceMillis: Long,
    val untilMillis: Long,
    val dayStartsMillis: List<Long>,
)

@Immutable
data class WeeklyRoomDayStat(
    val dayIndex: Int,
    val dayStartMillis: Long,
    val dayLabelShort: String,
    val dayDateLabel: String,
    val totalCount: Int,
    val criticalCount: Int,
    val highCount: Int,
    val mediumCount: Int,
    val resolvedCount: Int,
)

@Immutable
data class WeeklyRoomCategoryStat(
    val category: PhishingCategory,
    val count: Int,
    val percentage: Float,
    val resolvedCount: Int,
)

@Immutable
data class WeeklyRoomActionStat(
    val action: IncidentActionTaken,
    val count: Int,
)

@Immutable
data class WeeklyRoomSummaryReport(
    val userId: String,
    val accountLabel: String,
    val sinceMillis: Long,
    val untilMillis: Long,
    val generatedAtMillis: Long,
    val periodStartLabel: String,
    val periodEndLabel: String,
    val generatedAtLabel: String,
    val totalIncidents: Int,
    val criticalCount: Int,
    val highCount: Int,
    val mediumCount: Int,
    val resolvedCount: Int,
    val pendingCount: Int,
    val resolutionRatePercent: Int,
    val dailyStats: List<WeeklyRoomDayStat>,
    val categoryStats: List<WeeklyRoomCategoryStat>,
    val actionStats: List<WeeklyRoomActionStat>,
    val incidents: List<ThreatIncidentEntity>,
)

object WeeklyRoomSummaryBuilder {

    private const val DAYS_IN_WEEK = 7
    private const val MILLIS_PER_DAY = 86_400_000L

    fun computeRollingWeekWindow(
        nowMillis: Long = System.currentTimeMillis(),
        timeZone: TimeZone = TimeZone.getDefault(),
    ): WeeklyRoomWindow {
        val cal = Calendar.getInstance(timeZone, Locale.US).apply {
            timeInMillis = nowMillis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val todayStartMillis = cal.timeInMillis
        val sinceMillis = todayStartMillis - (DAYS_IN_WEEK - 1) * MILLIS_PER_DAY
        val untilMillis = todayStartMillis + MILLIS_PER_DAY
        val dayStarts = List(DAYS_IN_WEEK) { idx ->
            sinceMillis + idx * MILLIS_PER_DAY
        }
        return WeeklyRoomWindow(
            sinceMillis = sinceMillis,
            untilMillis = untilMillis,
            dayStartsMillis = dayStarts,
        )
    }

    fun build(
        userId: String,
        accountLabel: String,
        incidents: List<ThreatIncidentEntity>,
        language: AppLanguage = AppLanguage.AR,
        nowMillis: Long = System.currentTimeMillis(),
        timeZone: TimeZone = TimeZone.getDefault(),
    ): WeeklyRoomSummaryReport {
        val window = computeRollingWeekWindow(nowMillis = nowMillis, timeZone = timeZone)
        val locale = if (language == AppLanguage.AR) Locale.forLanguageTag("ar") else Locale.US
        val dayNameFormat = SimpleDateFormat("EEE", locale).apply { this.timeZone = timeZone }
        val shortDateFormat = SimpleDateFormat("dd/MM", Locale.US).apply { this.timeZone = timeZone }
        val periodDateFormat = SimpleDateFormat("dd MMM yyyy", Locale.US).apply { this.timeZone = timeZone }
        val generatedFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US).apply { this.timeZone = timeZone }

        val inWindowIncidents = incidents
            .filter {
                it.userId == userId &&
                    it.detectedAtMillis >= window.sinceMillis &&
                    it.detectedAtMillis < window.untilMillis
            }
            .sortedWith(compareByDescending<ThreatIncidentEntity> { it.detectedAtMillis }.thenByDescending { it.id })

        val perDayBuckets = Array(DAYS_IN_WEEK) { mutableListOf<ThreatIncidentEntity>() }
        for (incident in inWindowIncidents) {
            val dayIdx = ((incident.detectedAtMillis - window.sinceMillis) / MILLIS_PER_DAY)
                .toInt()
                .coerceIn(0, DAYS_IN_WEEK - 1)
            perDayBuckets[dayIdx].add(incident)
        }

        val dailyStats = List(DAYS_IN_WEEK) { idx ->
            val dayStart = window.dayStartsMillis[idx]
            val dayDate = Date(dayStart)
            val bucket = perDayBuckets[idx]
            WeeklyRoomDayStat(
                dayIndex = idx,
                dayStartMillis = dayStart,
                dayLabelShort = dayNameFormat.format(dayDate),
                dayDateLabel = shortDateFormat.format(dayDate),
                totalCount = bucket.size,
                criticalCount = bucket.count { it.parsedSeverity == ThreatSeverity.CRITICAL },
                highCount = bucket.count { it.parsedSeverity == ThreatSeverity.HIGH },
                mediumCount = bucket.count { it.parsedSeverity == ThreatSeverity.MEDIUM },
                resolvedCount = bucket.count { it.resolved },
            )
        }

        val total = inWindowIncidents.size
        val critical = inWindowIncidents.count { it.parsedSeverity == ThreatSeverity.CRITICAL }
        val high = inWindowIncidents.count { it.parsedSeverity == ThreatSeverity.HIGH }
        val medium = inWindowIncidents.count { it.parsedSeverity == ThreatSeverity.MEDIUM }
        val resolved = inWindowIncidents.count { it.resolved }
        val pending = (total - resolved).coerceAtLeast(0)
        val resolutionRate = if (total == 0) 100 else ((resolved * 100f) / total).roundToInt()

        val categoryStats = PhishingCategory.entries
            .mapNotNull { category ->
                val matching = inWindowIncidents.filter { it.parsedCategory == category }
                if (matching.isEmpty()) {
                    null
                } else {
                    WeeklyRoomCategoryStat(
                        category = category,
                        count = matching.size,
                        percentage = if (total == 0) 0f else (matching.size * 100f) / total,
                        resolvedCount = matching.count { it.resolved },
                    )
                }
            }
            .sortedByDescending { it.count }

        val actionStats = IncidentActionTaken.entries
            .mapNotNull { action ->
                val count = inWindowIncidents.count { it.parsedAction == action }
                if (count == 0) null else WeeklyRoomActionStat(action = action, count = count)
            }
            .sortedByDescending { it.count }

        return WeeklyRoomSummaryReport(
            userId = userId,
            accountLabel = accountLabel.ifBlank { userId },
            sinceMillis = window.sinceMillis,
            untilMillis = window.untilMillis,
            generatedAtMillis = nowMillis,
            periodStartLabel = periodDateFormat.format(Date(window.sinceMillis)),
            periodEndLabel = periodDateFormat.format(Date(nowMillis)),
            generatedAtLabel = generatedFormat.format(Date(nowMillis)),
            totalIncidents = total,
            criticalCount = critical,
            highCount = high,
            mediumCount = medium,
            resolvedCount = resolved,
            pendingCount = pending,
            resolutionRatePercent = resolutionRate,
            dailyStats = dailyStats,
            categoryStats = categoryStats,
            actionStats = actionStats,
            incidents = inWindowIncidents,
        )
    }
}
