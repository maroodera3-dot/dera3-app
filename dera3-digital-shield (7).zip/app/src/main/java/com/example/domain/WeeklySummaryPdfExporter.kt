package com.example.domain

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.text.TextUtils
import androidx.core.content.FileProvider
import com.example.data.local.IncidentActionTaken
import com.example.data.local.ThreatIncidentEntity
import com.example.data.model.PhishingCategory
import com.example.data.model.ThreatSeverity
import com.example.localization.AppLanguage
import com.example.localization.Dera3Strings
import com.example.localization.LocalizationManager
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

data class ExportedPdfResult(
    val file: File,
    val contentUri: Uri,
    val fileName: String,
    val byteCount: Long,
    val pageCount: Int,
)

object WeeklySummaryPdfExporter {

    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842
    private const val MARGIN = 28f
    private const val CONTENT_WIDTH = PAGE_WIDTH - MARGIN * 2f
    private const val REPORT_DIR_NAME = "weekly_reports"
    private const val MAX_CACHE_AGE_MILLIS = 24L * 60L * 60L * 1000L

    private val COLOR_PAGE_BG = Color.rgb(245, 247, 251)
    private val COLOR_CARD_BG = Color.WHITE
    private val COLOR_CARD_BORDER = Color.rgb(222, 228, 238)
    private val COLOR_BRAND_DARK = Color.rgb(12, 34, 68)
    private val COLOR_BRAND_PRIMARY = Color.rgb(19, 93, 216)
    private val COLOR_BRAND_SOFT = Color.rgb(232, 241, 255)
    private val COLOR_TEXT_PRIMARY = Color.rgb(17, 24, 39)
    private val COLOR_TEXT_MUTED = Color.rgb(92, 104, 122)
    private val COLOR_DANGER = Color.rgb(211, 47, 47)
    private val COLOR_DANGER_SOFT = Color.rgb(253, 235, 235)
    private val COLOR_CAUTION = Color.rgb(217, 119, 6)
    private val COLOR_CAUTION_SOFT = Color.rgb(254, 243, 199)
    private val COLOR_SAFE = Color.rgb(16, 138, 72)
    private val COLOR_SAFE_SOFT = Color.rgb(225, 247, 234)
    private val COLOR_VIOLET = Color.rgb(124, 58, 237)
    private val COLOR_TRACK = Color.rgb(230, 235, 243)

    fun exportWeeklySummaryPdf(
        context: Context,
        report: WeeklyRoomSummaryReport,
        language: AppLanguage,
        strings: Dera3Strings,
    ): ExportedPdfResult {
        val reportsDir = File(context.cacheDir, REPORT_DIR_NAME).apply { mkdirs() }
        pruneOldReports(reportsDir, report.generatedAtMillis)

        val timestampSuffix = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
            .format(Date(report.generatedAtMillis))
        val fileName = "dera3_weekly_security_summary_$timestampSuffix.pdf"
        val outFile = File(reportsDir, fileName)

        val pdfDocument = PdfDocument()
        try {
            val isRtl = language == AppLanguage.AR
            val historyStrings = strings.threatHistory
            val weeklyStrings = strings.weeklyStats

            var pageNumber = 1
            var pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
            var page = pdfDocument.startPage(pageInfo)
            var canvas = page.canvas
            drawPageBackground(canvas)

            var y = MARGIN

            fun ensureSpace(requiredHeight: Float) {
                if (y + requiredHeight > PAGE_HEIGHT - MARGIN - 24f) {
                    drawPageFooter(canvas, pageNumber, report, strings, isRtl)
                    pdfDocument.finishPage(page)
                    pageNumber++
                    pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
                    page = pdfDocument.startPage(pageInfo)
                    canvas = page.canvas
                    drawPageBackground(canvas)
                    y = MARGIN
                }
            }

            // 1. Hero Header Card
            y = drawHeroHeaderCard(
                canvas = canvas,
                top = y,
                report = report,
                strings = strings,
                isRtl = isRtl,
            )
            y += 12f

            // 2. 4 KPI Summary Cards Row
            y = drawKpiRow(
                canvas = canvas,
                top = y,
                report = report,
                strings = strings,
                isRtl = isRtl,
            )
            y += 12f

            // 3. 7-Day Activity Bar Chart Card
            ensureSpace(148f)
            y = drawDailyActivityCard(
                canvas = canvas,
                top = y,
                report = report,
                strings = strings,
                isRtl = isRtl,
            )
            y += 12f

            // 4. Category Breakdown & Actions Taken Side-by-Side (or stacked)
            val catHeight = if (report.categoryStats.isEmpty()) 78f else 54f + report.categoryStats.size * 28f
            val actionHeight = if (report.actionStats.isEmpty()) 78f else 54f + report.actionStats.size * 24f
            val breakdownCardHeight = max(catHeight, actionHeight)
            ensureSpace(breakdownCardHeight + 12f)
            y = drawBreakdownPairCards(
                canvas = canvas,
                top = y,
                cardHeight = breakdownCardHeight,
                report = report,
                strings = strings,
                isRtl = isRtl,
            )
            y += 12f

            // 5. Recent Weekly Incidents Section Header
            ensureSpace(64f)
            val sectionHeaderPaint = createTextPaint(13f, COLOR_TEXT_PRIMARY, bold = true)
            drawTextBlock(
                canvas = canvas,
                text = historyStrings.pdfIncidentsTitle,
                x = MARGIN,
                y = y,
                width = CONTENT_WIDTH,
                paint = sectionHeaderPaint,
                isRtl = isRtl,
            )
            y += 22f

            if (report.incidents.isEmpty()) {
                ensureSpace(64f)
                val emptyBox = RectF(MARGIN, y, MARGIN + CONTENT_WIDTH, y + 54f)
                drawRoundedCard(canvas, emptyBox, COLOR_SAFE_SOFT, COLOR_SAFE)
                val emptyPaint = createTextPaint(10.5f, COLOR_SAFE, bold = true)
                drawTextBlock(
                    canvas = canvas,
                    text = historyStrings.pdfNoIncidents,
                    x = MARGIN + 14f,
                    y = y + 16f,
                    width = CONTENT_WIDTH - 28f,
                    paint = emptyPaint,
                    isRtl = isRtl,
                )
                y += 62f
            } else {
                val incidentsToRender = report.incidents.take(15)
                for (incident in incidentsToRender) {
                    val cardHeight = measureIncidentCardHeight(incident, language, strings)
                    ensureSpace(cardHeight + 8f)
                    y = drawIncidentSummaryCard(
                        canvas = canvas,
                        top = y,
                        incident = incident,
                        language = language,
                        strings = strings,
                        isRtl = isRtl,
                    )
                    y += 8f
                }
            }

            drawPageFooter(canvas, pageNumber, report, strings, isRtl)
            pdfDocument.finishPage(page)

            FileOutputStream(outFile).use { fos ->
                pdfDocument.writeTo(fos)
                fos.flush()
            }
        } finally {
            pdfDocument.close()
        }

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            outFile,
        )

        return ExportedPdfResult(
            file = outFile,
            contentUri = uri,
            fileName = fileName,
            byteCount = outFile.length(),
            pageCount = countPagesInPdfOrDefault(outFile),
        )
    }

    fun createShareIntent(
        context: Context,
        exported: ExportedPdfResult,
        report: WeeklyRoomSummaryReport,
        strings: Dera3Strings,
    ): Intent {
        val historyStrings = strings.threatHistory
        val subject = LocalizationManager.formatString(
            historyStrings.sharePdfSubjectFormat,
            report.periodStartLabel,
            report.periodEndLabel,
        )
        val summaryText = buildString {
            append(subject)
            append("\n")
            append("${strings.weeklyStats.totalThreatsLabel}: ${report.totalIncidents}")
            append(" | ")
            append("${strings.weeklyStats.criticalHighLabel}: ${report.criticalCount + report.highCount}")
            append(" | ")
            append("${strings.weeklyStats.resolvedRateLabel}: ${report.resolutionRatePercent}%")
        }

        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, exported.contentUri)
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, summaryText)
            clipData = ClipData.newRawUri(subject, exported.contentUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return Intent.createChooser(sendIntent, historyStrings.sharePdfChooser).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (context !is android.app.Activity) {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        }
    }

    fun createViewPdfIntent(
        context: Context,
        exported: ExportedPdfResult,
    ): Intent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(exported.contentUri, "application/pdf")
        clipData = ClipData.newRawUri(exported.fileName, exported.contentUri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        if (context !is android.app.Activity) {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun shareExportedPdf(
        context: Context,
        exported: ExportedPdfResult,
        report: WeeklyRoomSummaryReport,
        strings: Dera3Strings,
    ): Result<Unit> = runCatching {
        context.startActivity(createShareIntent(context, exported, report, strings))
    }

    fun openExportedPdf(
        context: Context,
        exported: ExportedPdfResult,
    ): Result<Unit> = runCatching {
        context.startActivity(createViewPdfIntent(context, exported))
    }.recoverCatching { err ->
        if (err is ActivityNotFoundException) {
            throw err
        }
        throw err
    }

    private fun pruneOldReports(dir: File, nowMillis: Long) {
        dir.listFiles()?.forEach { file ->
            if (nowMillis - file.lastModified() > MAX_CACHE_AGE_MILLIS) {
                file.delete()
            }
        }
    }

    private fun countPagesInPdfOrDefault(file: File): Int {
        // Count PDF page markers ("/Type /Page\b") as a lightweight verification fallback
        return runCatching {
            val text = file.readText(Charsets.ISO_8859_1)
            val matches = Regex("/Type\\s*/Page\\b").findAll(text).count()
            if (matches > 0) matches else 1
        }.getOrDefault(1)
    }

    private fun drawPageBackground(canvas: Canvas) {
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_PAGE_BG
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), PAGE_HEIGHT.toFloat(), bgPaint)
    }

    private fun drawRoundedCard(
        canvas: Canvas,
        rect: RectF,
        fillColor: Int = COLOR_CARD_BG,
        borderColor: Int = COLOR_CARD_BORDER,
        radius: Float = 14f,
        strokeWidth: Float = 1f,
    ) {
        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = fillColor
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(rect, radius, radius, fillPaint)

        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = borderColor
            style = Paint.Style.STROKE
            this.strokeWidth = strokeWidth
        }
        canvas.drawRoundRect(rect, radius, radius, borderPaint)
    }

    private fun drawHeroHeaderCard(
        canvas: Canvas,
        top: Float,
        report: WeeklyRoomSummaryReport,
        strings: Dera3Strings,
        isRtl: Boolean,
    ): Float {
        val historyStrings = strings.threatHistory
        val cardHeight = 104f
        val rect = RectF(MARGIN, top, MARGIN + CONTENT_WIDTH, top + cardHeight)
        drawRoundedCard(canvas, rect, fillColor = COLOR_BRAND_DARK, borderColor = COLOR_BRAND_DARK, radius = 16f)

        // Subtle accent pill bar on top edge
        val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = COLOR_BRAND_PRIMARY }
        canvas.drawRoundRect(
            RectF(MARGIN + 14f, top + 10f, MARGIN + 86f, top + 14f),
            2f,
            2f,
            accentPaint,
        )

        val badgePaint = createTextPaint(9f, Color.rgb(147, 197, 253), bold = true)
        drawTextBlock(
            canvas = canvas,
            text = "${strings.appName} • ${historyStrings.pdfSourceBadge}",
            x = MARGIN + 16f,
            y = top + 20f,
            width = CONTENT_WIDTH - 32f,
            paint = badgePaint,
            isRtl = isRtl,
        )

        val titlePaint = createTextPaint(16.5f, Color.WHITE, bold = true)
        drawTextBlock(
            canvas = canvas,
            text = historyStrings.pdfSheetTitle,
            x = MARGIN + 16f,
            y = top + 36f,
            width = CONTENT_WIDTH - 32f,
            paint = titlePaint,
            isRtl = isRtl,
        )

        val metaPaint = createTextPaint(10f, Color.rgb(209, 219, 235), bold = false)
        val periodLine = LocalizationManager.formatString(
            historyStrings.pdfPeriodFormat,
            report.periodStartLabel,
            report.periodEndLabel,
        )
        drawTextBlock(
            canvas = canvas,
            text = "$periodLine  |  ${report.accountLabel}",
            x = MARGIN + 16f,
            y = top + 64f,
            width = CONTENT_WIDTH - 32f,
            paint = metaPaint,
            isRtl = isRtl,
        )

        val genLine = LocalizationManager.formatString(
            historyStrings.pdfGeneratedAtFormat,
            report.generatedAtLabel,
        )
        drawTextBlock(
            canvas = canvas,
            text = genLine,
            x = MARGIN + 16f,
            y = top + 80f,
            width = CONTENT_WIDTH - 32f,
            paint = metaPaint,
            isRtl = isRtl,
        )

        return top + cardHeight
    }

    private fun drawKpiRow(
        canvas: Canvas,
        top: Float,
        report: WeeklyRoomSummaryReport,
        strings: Dera3Strings,
        isRtl: Boolean,
    ): Float {
        val tileHeight = 64f
        val gap = 8f
        val tileWidth = (CONTENT_WIDTH - gap * 3f) / 4f

        data class KpiSpec(
            val value: String,
            val label: String,
            val fillColor: Int,
            val accentColor: Int,
        )

        val specs = listOf(
            KpiSpec(
                value = "${report.totalIncidents}",
                label = strings.weeklyStats.totalThreatsLabel,
                fillColor = COLOR_BRAND_SOFT,
                accentColor = COLOR_BRAND_PRIMARY,
            ),
            KpiSpec(
                value = "${report.criticalCount + report.highCount}",
                label = strings.weeklyStats.criticalHighLabel,
                fillColor = COLOR_DANGER_SOFT,
                accentColor = COLOR_DANGER,
            ),
            KpiSpec(
                value = "${report.resolvedCount}",
                label = strings.threatHistory.filterResolved,
                fillColor = COLOR_SAFE_SOFT,
                accentColor = COLOR_SAFE,
            ),
            KpiSpec(
                value = "${report.resolutionRatePercent}%",
                label = strings.weeklyStats.resolvedRateLabel,
                fillColor = COLOR_CAUTION_SOFT,
                accentColor = COLOR_CAUTION,
            ),
        )

        specs.forEachIndexed { idx, spec ->
            val left = MARGIN + idx * (tileWidth + gap)
            val rect = RectF(left, top, left + tileWidth, top + tileHeight)
            drawRoundedCard(canvas, rect, fillColor = spec.fillColor, borderColor = spec.accentColor.withAlpha(70), radius = 12f)

            val valuePaint = createTextPaint(17f, spec.accentColor, bold = true)
            drawTextBlock(
                canvas = canvas,
                text = spec.value,
                x = left + 8f,
                y = top + 11f,
                width = tileWidth - 16f,
                paint = valuePaint,
                isRtl = false,
                alignment = Layout.Alignment.ALIGN_CENTER,
            )

            val labelPaint = createTextPaint(8.8f, COLOR_TEXT_PRIMARY, bold = false)
            drawTextBlock(
                canvas = canvas,
                text = spec.label,
                x = left + 6f,
                y = top + 36f,
                width = tileWidth - 12f,
                paint = labelPaint,
                isRtl = isRtl,
                alignment = Layout.Alignment.ALIGN_CENTER,
                maxLines = 2,
            )
        }

        return top + tileHeight
    }

    private fun drawDailyActivityCard(
        canvas: Canvas,
        top: Float,
        report: WeeklyRoomSummaryReport,
        strings: Dera3Strings,
        isRtl: Boolean,
    ): Float {
        val cardHeight = 142f
        val rect = RectF(MARGIN, top, MARGIN + CONTENT_WIDTH, top + cardHeight)
        drawRoundedCard(canvas, rect)

        val titlePaint = createTextPaint(11.5f, COLOR_TEXT_PRIMARY, bold = true)
        drawTextBlock(
            canvas = canvas,
            text = strings.threatHistory.pdfDailyTitle,
            x = MARGIN + 14f,
            y = top + 12f,
            width = CONTENT_WIDTH - 28f,
            paint = titlePaint,
            isRtl = isRtl,
        )

        val chartLeft = MARGIN + 20f
        val chartRight = MARGIN + CONTENT_WIDTH - 20f
        val chartWidth = chartRight - chartLeft
        val chartTop = top + 40f
        val chartBottom = top + 106f
        val chartHeight = chartBottom - chartTop

        val axisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_CARD_BORDER
            strokeWidth = 1f
        }
        canvas.drawLine(chartLeft, chartBottom, chartRight, chartBottom, axisPaint)
        canvas.drawLine(chartLeft, chartTop + chartHeight * 0.5f, chartRight, chartTop + chartHeight * 0.5f, axisPaint)

        val maxDaily = max(1, report.dailyStats.maxOfOrNull { it.totalCount } ?: 1)
        val slotWidth = chartWidth / report.dailyStats.size.coerceAtLeast(1)
        val barWidth = (slotWidth * 0.42f).coerceIn(14f, 28f)

        val critPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = COLOR_DANGER }
        val highPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = COLOR_CAUTION }
        val medPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = COLOR_BRAND_PRIMARY }
        val emptyBarPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = COLOR_TRACK }
        val countPaint = createTextPaint(8.5f, COLOR_TEXT_MUTED, bold = true)
        val dayPaint = createTextPaint(8.5f, COLOR_TEXT_PRIMARY, bold = false)

        report.dailyStats.forEachIndexed { idx, bucket ->
            val slotStart = chartLeft + idx * slotWidth
            val barLeft = slotStart + (slotWidth - barWidth) / 2f

            if (bucket.totalCount == 0) {
                canvas.drawRoundRect(
                    RectF(barLeft, chartBottom - 4f, barLeft + barWidth, chartBottom),
                    2f,
                    2f,
                    emptyBarPaint,
                )
            } else {
                val medH = (bucket.mediumCount.toFloat() / maxDaily) * chartHeight
                val highH = (bucket.highCount.toFloat() / maxDaily) * chartHeight
                val critH = (bucket.criticalCount.toFloat() / maxDaily) * chartHeight
                var curBottom = chartBottom
                if (medH > 0f) {
                    canvas.drawRoundRect(
                        RectF(barLeft, curBottom - medH, barLeft + barWidth, curBottom),
                        3f,
                        3f,
                        medPaint,
                    )
                    curBottom -= medH
                }
                if (highH > 0f) {
                    canvas.drawRoundRect(
                        RectF(barLeft, curBottom - highH, barLeft + barWidth, curBottom),
                        3f,
                        3f,
                        highPaint,
                    )
                    curBottom -= highH
                }
                if (critH > 0f) {
                    canvas.drawRoundRect(
                        RectF(barLeft, curBottom - critH, barLeft + barWidth, curBottom),
                        3f,
                        3f,
                        critPaint,
                    )
                }
            }

            drawTextBlock(
                canvas = canvas,
                text = "${bucket.totalCount}",
                x = slotStart,
                y = chartTop - 13f,
                width = slotWidth,
                paint = countPaint,
                isRtl = false,
                alignment = Layout.Alignment.ALIGN_CENTER,
            )

            drawTextBlock(
                canvas = canvas,
                text = "${bucket.dayLabelShort}\n${bucket.dayDateLabel}",
                x = slotStart,
                y = chartBottom + 4f,
                width = slotWidth,
                paint = dayPaint,
                isRtl = isRtl,
                alignment = Layout.Alignment.ALIGN_CENTER,
                maxLines = 2,
            )
        }

        return top + cardHeight
    }

    private fun drawBreakdownPairCards(
        canvas: Canvas,
        top: Float,
        cardHeight: Float,
        report: WeeklyRoomSummaryReport,
        strings: Dera3Strings,
        isRtl: Boolean,
    ): Float {
        val gap = 10f
        val halfWidth = (CONTENT_WIDTH - gap) / 2f

        // Left Card: Categories
        val catRect = RectF(MARGIN, top, MARGIN + halfWidth, top + cardHeight)
        drawRoundedCard(canvas, catRect)

        val headerPaint = createTextPaint(11f, COLOR_TEXT_PRIMARY, bold = true)
        val bodyPaint = createTextPaint(9.2f, COLOR_TEXT_PRIMARY, bold = false)
        val mutedPaint = createTextPaint(9f, COLOR_TEXT_MUTED, bold = false)
        val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = COLOR_TRACK }

        drawTextBlock(
            canvas = canvas,
            text = strings.threatHistory.pdfCategoriesTitle,
            x = catRect.left + 12f,
            y = top + 12f,
            width = halfWidth - 24f,
            paint = headerPaint,
            isRtl = isRtl,
        )

        if (report.categoryStats.isEmpty()) {
            drawTextBlock(
                canvas = canvas,
                text = "—",
                x = catRect.left + 12f,
                y = top + 38f,
                width = halfWidth - 24f,
                paint = mutedPaint,
                isRtl = isRtl,
            )
        } else {
            var cy = top + 36f
            report.categoryStats.forEach { stat ->
                val catName = categoryDisplayName(stat.category, strings)
                drawTextBlock(
                    canvas = canvas,
                    text = "$catName (${stat.count} • ${stat.percentage.roundToInt()}%)",
                    x = catRect.left + 12f,
                    y = cy,
                    width = halfWidth - 24f,
                    paint = bodyPaint,
                    isRtl = isRtl,
                )
                val barTop = cy + 15f
                val barFullWidth = halfWidth - 24f
                canvas.drawRoundRect(
                    RectF(catRect.left + 12f, barTop, catRect.left + 12f + barFullWidth, barTop + 5f),
                    2.5f,
                    2.5f,
                    trackPaint,
                )
                val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = categoryAccentColor(stat.category) }
                val fillW = (barFullWidth * (stat.percentage / 100f)).coerceAtLeast(6f)
                canvas.drawRoundRect(
                    RectF(catRect.left + 12f, barTop, catRect.left + 12f + fillW, barTop + 5f),
                    2.5f,
                    2.5f,
                    fillPaint,
                )
                cy += 28f
            }
        }

        // Right Card: Actions Taken
        val actRect = RectF(MARGIN + halfWidth + gap, top, MARGIN + CONTENT_WIDTH, top + cardHeight)
        drawRoundedCard(canvas, actRect)

        drawTextBlock(
            canvas = canvas,
            text = strings.threatHistory.pdfActionsTitle,
            x = actRect.left + 12f,
            y = top + 12f,
            width = halfWidth - 24f,
            paint = headerPaint,
            isRtl = isRtl,
        )

        if (report.actionStats.isEmpty()) {
            drawTextBlock(
                canvas = canvas,
                text = "—",
                x = actRect.left + 12f,
                y = top + 38f,
                width = halfWidth - 24f,
                paint = mutedPaint,
                isRtl = isRtl,
            )
        } else {
            var ay = top + 38f
            report.actionStats.forEach { stat ->
                val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = actionAccentColor(stat.action) }
                canvas.drawCircle(actRect.left + 16f, ay + 6f, 3.5f, dotPaint)
                val actionLabel = actionDisplayName(stat.action, strings)
                drawTextBlock(
                    canvas = canvas,
                    text = "$actionLabel: ${stat.count}",
                    x = actRect.left + 25f,
                    y = ay,
                    width = halfWidth - 37f,
                    paint = bodyPaint,
                    isRtl = isRtl,
                )
                ay += 24f
            }
        }

        return top + cardHeight
    }

    private fun measureIncidentCardHeight(
        incident: ThreatIncidentEntity,
        language: AppLanguage,
        strings: Dera3Strings,
    ): Float {
        val message = LocalizationManager.resolveLocalizedText(language, incident.messageAr, incident.messageEn)
        var height = 56f
        if (message.isNotBlank()) height += 16f
        if (incident.indicator.isNotBlank()) height += 16f
        return height.coerceAtLeast(64f)
    }

    private fun drawIncidentSummaryCard(
        canvas: Canvas,
        top: Float,
        incident: ThreatIncidentEntity,
        language: AppLanguage,
        strings: Dera3Strings,
        isRtl: Boolean,
    ): Float {
        val height = measureIncidentCardHeight(incident, language, strings)
        val rect = RectF(MARGIN, top, MARGIN + CONTENT_WIDTH, top + height)
        val severityColor = when (incident.parsedSeverity) {
            ThreatSeverity.CRITICAL -> COLOR_DANGER
            ThreatSeverity.HIGH -> COLOR_CAUTION
            ThreatSeverity.MEDIUM -> COLOR_BRAND_PRIMARY
        }
        drawRoundedCard(canvas, rect, borderColor = severityColor.withAlpha(110), radius = 12f)

        // Left severity accent stripe
        val stripePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = severityColor }
        canvas.drawRoundRect(
            RectF(rect.left + 6f, rect.top + 8f, rect.left + 10f, rect.bottom - 8f),
            2f,
            2f,
            stripePaint,
        )

        val title = LocalizationManager.resolveLocalizedText(language, incident.titleAr, incident.titleEn)
        val message = LocalizationManager.resolveLocalizedText(language, incident.messageAr, incident.messageEn)
        val shieldName = strings.shieldTitles.getOrElse(incident.targetShield.index) { incident.targetShield.name }
        val actionLabel = actionDisplayName(incident.parsedAction, strings)
        val sevLabel = when (incident.parsedSeverity) {
            ThreatSeverity.CRITICAL -> strings.phishingSeverityCritical
            ThreatSeverity.HIGH -> strings.phishingSeverityHigh
            ThreatSeverity.MEDIUM -> strings.phishingSeverityMedium
        }
        val tsLabel = SimpleDateFormat("dd/MM HH:mm", Locale.US).format(Date(incident.detectedAtMillis))

        val titlePaint = createTextPaint(10.5f, COLOR_TEXT_PRIMARY, bold = true)
        val metaPaint = createTextPaint(8.8f, COLOR_TEXT_MUTED, bold = false)
        val actionPaint = createTextPaint(9f, actionAccentColor(incident.parsedAction), bold = true)

        var cy = top + 10f
        drawTextBlock(
            canvas = canvas,
            text = "[$sevLabel] $title",
            x = rect.left + 18f,
            y = cy,
            width = CONTENT_WIDTH - 125f,
            paint = titlePaint,
            isRtl = isRtl,
            maxLines = 1,
        )
        drawTextBlock(
            canvas = canvas,
            text = tsLabel,
            x = rect.right - 102f,
            y = cy + 1f,
            width = 90f,
            paint = metaPaint,
            isRtl = false,
            alignment = Layout.Alignment.ALIGN_OPPOSITE,
        )
        cy += 16f

        if (message.isNotBlank()) {
            drawTextBlock(
                canvas = canvas,
                text = message,
                x = rect.left + 18f,
                y = cy,
                width = CONTENT_WIDTH - 30f,
                paint = metaPaint,
                isRtl = isRtl,
                maxLines = 1,
            )
            cy += 15f
        }

        if (incident.indicator.isNotBlank()) {
            drawTextBlock(
                canvas = canvas,
                text = incident.indicator,
                x = rect.left + 18f,
                y = cy,
                width = CONTENT_WIDTH - 30f,
                paint = metaPaint,
                isRtl = false,
                maxLines = 1,
            )
            cy += 15f
        }

        drawTextBlock(
            canvas = canvas,
            text = "$shieldName  •  ${strings.threatHistory.actionLabel} $actionLabel",
            x = rect.left + 18f,
            y = cy,
            width = CONTENT_WIDTH - 30f,
            paint = actionPaint,
            isRtl = isRtl,
            maxLines = 1,
        )

        return top + height
    }

    private fun drawPageFooter(
        canvas: Canvas,
        pageNumber: Int,
        report: WeeklyRoomSummaryReport,
        strings: Dera3Strings,
        isRtl: Boolean,
    ) {
        val footerY = PAGE_HEIGHT - MARGIN + 4f
        val footerPaint = createTextPaint(8.5f, COLOR_TEXT_MUTED, bold = false)
        drawTextBlock(
            canvas = canvas,
            text = "${strings.appName} • ${strings.threatHistory.pdfSourceBadge}",
            x = MARGIN,
            y = footerY,
            width = CONTENT_WIDTH - 60f,
            paint = footerPaint,
            isRtl = isRtl,
        )
        drawTextBlock(
            canvas = canvas,
            text = "#$pageNumber",
            x = MARGIN + CONTENT_WIDTH - 55f,
            y = footerY,
            width = 55f,
            paint = footerPaint,
            isRtl = false,
            alignment = Layout.Alignment.ALIGN_OPPOSITE,
        )
    }

    private fun createTextPaint(
        sizeSp: Float,
        color: Int,
        bold: Boolean,
    ): TextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        this.textSize = sizeSp
        this.color = color
        this.typeface = if (bold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
    }

    private fun drawTextBlock(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        width: Float,
        paint: TextPaint,
        isRtl: Boolean,
        alignment: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL,
        maxLines: Int = Int.MAX_VALUE,
    ) {
        val safeWidth = width.roundToInt().coerceAtLeast(1)
        val layout = StaticLayout.Builder
            .obtain(text, 0, text.length, paint, safeWidth)
            .setAlignment(alignment)
            .setTextDirection(
                if (isRtl) TextDirectionHeuristics.FIRSTSTRONG_RTL else TextDirectionHeuristics.FIRSTSTRONG_LTR
            )
            .setLineSpacing(0f, 1.05f)
            .setMaxLines(maxLines)
            .setEllipsize(TextUtils.TruncateAt.END)
            .build()

        canvas.save()
        canvas.translate(x, y)
        layout.draw(canvas)
        canvas.restore()
    }

    fun categoryDisplayName(category: PhishingCategory, strings: Dera3Strings): String = when (category) {
        PhishingCategory.LINK_PHISHING -> strings.weeklyStats.catLinkPhishing
        PhishingCategory.BANK_IMPERSONATION -> strings.weeklyStats.catBankImpersonation
        PhishingCategory.FAKE_APP -> strings.weeklyStats.catFakeApp
        PhishingCategory.OTP_SCAM -> strings.weeklyStats.catOtpScam
        PhishingCategory.SMS_DELIVERY -> strings.weeklyStats.catSmsDelivery
    }

    fun actionDisplayName(action: IncidentActionTaken, strings: Dera3Strings): String = when (action) {
        IncidentActionTaken.DETECTED_LOGGED -> strings.threatHistory.actionDetected
        IncidentActionTaken.BLOCKED_AUTO -> strings.threatHistory.actionBlocked
        IncidentActionTaken.USER_INSPECTED -> strings.threatHistory.actionInspected
        IncidentActionTaken.SHIELD_SECURED -> strings.threatHistory.actionSecured
        IncidentActionTaken.USER_DISMISSED -> strings.threatHistory.actionDismissed
    }

    private fun categoryAccentColor(category: PhishingCategory): Int = when (category) {
        PhishingCategory.LINK_PHISHING -> COLOR_BRAND_PRIMARY
        PhishingCategory.BANK_IMPERSONATION -> COLOR_DANGER
        PhishingCategory.FAKE_APP -> COLOR_VIOLET
        PhishingCategory.OTP_SCAM -> COLOR_CAUTION
        PhishingCategory.SMS_DELIVERY -> COLOR_SAFE
    }

    private fun actionAccentColor(action: IncidentActionTaken): Int = when (action) {
        IncidentActionTaken.DETECTED_LOGGED -> COLOR_DANGER
        IncidentActionTaken.BLOCKED_AUTO -> COLOR_BRAND_PRIMARY
        IncidentActionTaken.USER_INSPECTED -> COLOR_CAUTION
        IncidentActionTaken.SHIELD_SECURED -> COLOR_SAFE
        IncidentActionTaken.USER_DISMISSED -> COLOR_TEXT_MUTED
    }

    private fun Int.withAlpha(alpha: Int): Int =
        Color.argb(alpha.coerceIn(0, 255), Color.red(this), Color.green(this), Color.blue(this))
}
