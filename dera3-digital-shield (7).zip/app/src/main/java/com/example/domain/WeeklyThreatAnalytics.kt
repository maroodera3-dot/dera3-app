package com.example.domain

import androidx.compose.runtime.Immutable
import com.example.data.model.PhishingCategory
import com.example.data.model.PhishingNotificationItem
import com.example.data.model.ThreatSeverity
import com.example.localization.AppLanguage
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.roundToInt

@Immutable
data class DailyThreatBucket(
    val dayIndex: Int,
    val dayStartEpochSec: Long,
    val dayLabelShort: String,
    val dayDateLabel: String,
    val totalCount: Int,
    val criticalCount: Int,
    val highCount: Int,
    val mediumCount: Int,
    val handledCount: Int,
    val categoryCounts: Map<PhishingCategory, Int>,
) {
    val dominantCategory: PhishingCategory?
        get() = categoryCounts.maxByOrNull { it.value }?.key
}

@Immutable
data class CategoryBreakdownSlice(
    val category: PhishingCategory,
    val count: Int,
    val percentage: Float,
    val criticalCount: Int,
    val highCount: Int,
    val mediumCount: Int,
)

@Immutable
data class WeeklyThreatSummary(
    val totalThreats: Int,
    val criticalCount: Int,
    val highCount: Int,
    val mediumCount: Int,
    val handledCount: Int,
    val activeUnresolvedCount: Int,
    val resolutionRatePercent: Int,
    val topCategory: PhishingCategory?,
    val peakDay: DailyThreatBucket?,
    val dailyBuckets: List<DailyThreatBucket>,
    val categoryBreakdown: List<CategoryBreakdownSlice>,
    val isUsingSamplePreview: Boolean,
)

object WeeklyThreatAggregator {

    private const val DAYS_IN_WEEK = 7
    private const val SECONDS_PER_DAY = 86_400L

    fun buildWeeklySummary(
        items: List<PhishingNotificationItem>,
        nowMillis: Long = System.currentTimeMillis(),
        language: AppLanguage = AppLanguage.AR,
        timeZone: TimeZone = TimeZone.getDefault(),
        isSamplePreview: Boolean = false,
    ): WeeklyThreatSummary {
        val locale = if (language == AppLanguage.AR) Locale.forLanguageTag("ar") else Locale.US
        val dayNameFormat = SimpleDateFormat("EEE", locale).apply { this.timeZone = timeZone }
        val dayDateFormat = SimpleDateFormat("dd/MM", Locale.US).apply { this.timeZone = timeZone }

        val cal = Calendar.getInstance(timeZone, Locale.US).apply {
            timeInMillis = nowMillis
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val todayStartSec = cal.timeInMillis / 1000L
        val weekStartSec = todayStartSec - (DAYS_IN_WEEK - 1) * SECONDS_PER_DAY
        val weekEndExclusiveSec = todayStartSec + SECONDS_PER_DAY

        val dayStarts = LongArray(DAYS_IN_WEEK) { idx ->
            weekStartSec + idx * SECONDS_PER_DAY
        }

        val itemsPerDay = Array(DAYS_IN_WEEK) { mutableListOf<PhishingNotificationItem>() }
        val inWindowItems = mutableListOf<PhishingNotificationItem>()

        for (item in items) {
            val ts = item.timestampSeconds
            if (ts in weekStartSec until weekEndExclusiveSec) {
                inWindowItems.add(item)
                val bucketIdx = ((ts - weekStartSec) / SECONDS_PER_DAY).toInt()
                    .coerceIn(0, DAYS_IN_WEEK - 1)
                itemsPerDay[bucketIdx].add(item)
            }
        }

        val dailyBuckets = List(DAYS_IN_WEEK) { idx ->
            val dayStartSec = dayStarts[idx]
            val dayDate = Date(dayStartSec * 1000L)
            val dayItems = itemsPerDay[idx]

            var critical = 0
            var high = 0
            var medium = 0
            var handled = 0
            val catCounts = linkedMapOf<PhishingCategory, Int>()

            for (item in dayItems) {
                when (item.severity) {
                    ThreatSeverity.CRITICAL -> critical++
                    ThreatSeverity.HIGH -> high++
                    ThreatSeverity.MEDIUM -> medium++
                }
                if (item.read || item.dismissed) handled++
                catCounts[item.category] = (catCounts[item.category] ?: 0) + 1
            }

            DailyThreatBucket(
                dayIndex = idx,
                dayStartEpochSec = dayStartSec,
                dayLabelShort = dayNameFormat.format(dayDate),
                dayDateLabel = dayDateFormat.format(dayDate),
                totalCount = dayItems.size,
                criticalCount = critical,
                highCount = high,
                mediumCount = medium,
                handledCount = handled,
                categoryCounts = catCounts,
            )
        }

        val total = inWindowItems.size
        val criticalTotal = inWindowItems.count { it.severity == ThreatSeverity.CRITICAL }
        val highTotal = inWindowItems.count { it.severity == ThreatSeverity.HIGH }
        val mediumTotal = inWindowItems.count { it.severity == ThreatSeverity.MEDIUM }
        val handledTotal = inWindowItems.count { it.read || it.dismissed }
        val activeTotal = (total - handledTotal).coerceAtLeast(0)
        val resolutionRate = if (total == 0) 100 else ((handledTotal * 100f) / total).roundToInt()

        val categoryBreakdown = PhishingCategory.entries
            .mapNotNull { category ->
                val catItems = inWindowItems.filter { it.category == category }
                if (catItems.isEmpty()) {
                    null
                } else {
                    CategoryBreakdownSlice(
                        category = category,
                        count = catItems.size,
                        percentage = if (total == 0) 0f else (catItems.size * 100f) / total,
                        criticalCount = catItems.count { it.severity == ThreatSeverity.CRITICAL },
                        highCount = catItems.count { it.severity == ThreatSeverity.HIGH },
                        mediumCount = catItems.count { it.severity == ThreatSeverity.MEDIUM },
                    )
                }
            }
            .sortedByDescending { it.count }

        val peakDay = dailyBuckets
            .filter { it.totalCount > 0 }
            .maxByOrNull { it.totalCount }

        return WeeklyThreatSummary(
            totalThreats = total,
            criticalCount = criticalTotal,
            highCount = highTotal,
            mediumCount = mediumTotal,
            handledCount = handledTotal,
            activeUnresolvedCount = activeTotal,
            resolutionRatePercent = resolutionRate,
            topCategory = categoryBreakdown.firstOrNull()?.category,
            peakDay = peakDay,
            dailyBuckets = dailyBuckets,
            categoryBreakdown = categoryBreakdown,
            isUsingSamplePreview = isSamplePreview,
        )
    }

    /**
     * Generates a deterministic 7-day sample dataset ONLY when the user explicitly turns on
     * "Sample Preview Mode" to inspect the weekly dashboard charts on an empty account.
     */
    fun buildSamplePreviewItems(nowMillis: Long = System.currentTimeMillis()): List<PhishingNotificationItem> {
        val anchorSec = (nowMillis / 1000L) - 1800L
        data class SeedSpec(
            val daysAgo: Int,
            val offsetSec: Long,
            val category: PhishingCategory,
            val severity: ThreatSeverity,
            val handled: Boolean,
        )

        val specs = listOf(
            SeedSpec(6, 3600L, PhishingCategory.LINK_PHISHING, ThreatSeverity.HIGH, true),
            SeedSpec(6, 7200L, PhishingCategory.SMS_DELIVERY, ThreatSeverity.MEDIUM, true),
            SeedSpec(5, 1800L, PhishingCategory.OTP_SCAM, ThreatSeverity.CRITICAL, true),
            SeedSpec(4, 2400L, PhishingCategory.BANK_IMPERSONATION, ThreatSeverity.CRITICAL, true),
            SeedSpec(4, 5400L, PhishingCategory.LINK_PHISHING, ThreatSeverity.HIGH, true),
            SeedSpec(4, 9000L, PhishingCategory.FAKE_APP, ThreatSeverity.MEDIUM, false),
            SeedSpec(3, 4200L, PhishingCategory.SMS_DELIVERY, ThreatSeverity.HIGH, true),
            SeedSpec(3, 8100L, PhishingCategory.LINK_PHISHING, ThreatSeverity.MEDIUM, true),
            SeedSpec(2, 1200L, PhishingCategory.FAKE_APP, ThreatSeverity.CRITICAL, true),
            SeedSpec(2, 4800L, PhishingCategory.OTP_SCAM, ThreatSeverity.HIGH, true),
            SeedSpec(2, 8400L, PhishingCategory.LINK_PHISHING, ThreatSeverity.HIGH, false),
            SeedSpec(2, 12000L, PhishingCategory.BANK_IMPERSONATION, ThreatSeverity.MEDIUM, true),
            SeedSpec(1, 3000L, PhishingCategory.BANK_IMPERSONATION, ThreatSeverity.CRITICAL, true),
            SeedSpec(1, 6600L, PhishingCategory.LINK_PHISHING, ThreatSeverity.HIGH, true),
            SeedSpec(1, 9900L, PhishingCategory.SMS_DELIVERY, ThreatSeverity.MEDIUM, true),
            SeedSpec(0, 900L, PhishingCategory.OTP_SCAM, ThreatSeverity.CRITICAL, false),
            SeedSpec(0, 2700L, PhishingCategory.LINK_PHISHING, ThreatSeverity.HIGH, true),
        )

        return specs.mapIndexed { idx, spec ->
            PhishingNotificationItem(
                id = "sample_weekly_$idx",
                isPersonalDetection = true,
                titleAr = "نموذج تهديد تجريبي",
                titleEn = "Sample Preview Threat",
                messageAr = "عينة إحصائية للعرض الأسبوعي",
                messageEn = "Weekly analytics preview sample",
                category = spec.category,
                severity = spec.severity,
                indicator = "sample-$idx",
                targetShield = spec.category.targetShield,
                read = spec.handled,
                dismissed = false,
                timestampSeconds = anchorSec - spec.daysAgo * SECONDS_PER_DAY - spec.offsetSec,
            )
        }
    }
}
