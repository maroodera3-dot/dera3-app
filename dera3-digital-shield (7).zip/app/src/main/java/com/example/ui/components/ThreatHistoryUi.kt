package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PhoneMissed
import androidx.compose.material.icons.filled.AppBlocking
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.GppGood
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SmsFailed
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.IncidentActionTaken
import com.example.data.local.ThreatIncidentEntity
import com.example.data.model.PhishingCategory
import com.example.data.model.ShieldId
import com.example.data.model.ThreatSeverity
import com.example.localization.AppLanguage
import com.example.localization.LocalStrings
import com.example.localization.LocalizationManager
import com.example.localization.ThreatHistoryStrings
import com.example.ui.theme.LocalDera3Colors
import com.example.ui.theme.MonoFontFamily
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class ThreatHistoryFilter {
    ALL,
    PENDING,
    RESOLVED,
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ThreatHistorySummaryCard(
    incidents: List<ThreatIncidentEntity>,
    language: AppLanguage,
    onOpenFullHistory: () -> Unit,
    onExportWeeklyPdf: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    val strings = LocalStrings.current
    val historyStrings = strings.threatHistory
    val dera3Colors = LocalDera3Colors.current

    val pendingCount = remember(incidents) { incidents.count { !it.resolved } }
    val resolvedCount = remember(incidents) { incidents.count { it.resolved } }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("local_threat_history_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Filled.History,
                        contentDescription = historyStrings.title,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp),
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = historyStrings.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = historyStrings.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (pendingCount > 0) dera3Colors.dangerContainer else MaterialTheme.colorScheme.surfaceVariant,
                ) {
                    Text(
                        text = LocalizationManager.formatString(historyStrings.pendingCountFormat, pendingCount),
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                        fontWeight = FontWeight.Bold,
                        color = if (pendingCount > 0) dera3Colors.danger else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    )
                }
                Surface(
                    shape = RoundedCornerShape(50),
                    color = dera3Colors.safeContainer,
                ) {
                    Text(
                        text = LocalizationManager.formatString(historyStrings.resolvedCountFormat, resolvedCount),
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                        fontWeight = FontWeight.Bold,
                        color = dera3Colors.safe,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    )
                }
            }

            if (incidents.isEmpty()) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("local_history_summary_empty"),
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.GppGood,
                            contentDescription = null,
                            tint = dera3Colors.safe,
                            modifier = Modifier.size(22.dp),
                        )
                        Text(
                            text = historyStrings.emptySubtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            } else {
                incidents.take(2).forEach { incident ->
                    val title = LocalizationManager.resolveLocalizedText(
                        language,
                        incident.titleAr,
                        incident.titleEn,
                    )
                    val actionLabel = localizedActionLabel(incident.parsedAction, historyStrings)
                    val actionColor = actionAccentColor(incident.parsedAction)

                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("local_history_preview_${incident.id}"),
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Icon(
                                imageVector = incidentCategoryIcon(incident.parsedCategory),
                                contentDescription = title,
                                tint = if (incident.resolved) dera3Colors.safe else dera3Colors.danger,
                                modifier = Modifier.size(20.dp),
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = title,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Text(
                                    text = "${historyStrings.actionLabel} $actionLabel",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = actionColor,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            Text(
                                text = formatIncidentTimestamp(incident.detectedAtMillis),
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }

            FilledTonalButton(
                onClick = onOpenFullHistory,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .testTag("open_local_threat_history_button"),
            ) {
                Icon(
                    imageVector = Icons.Filled.History,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = LocalizationManager.formatString(
                        historyStrings.viewAllBtnFormat,
                        incidents.size,
                    ),
                    fontWeight = FontWeight.Bold,
                )
            }

            if (onExportWeeklyPdf != null) {
                OutlinedButton(
                    onClick = onExportWeeklyPdf,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("export_weekly_pdf_button"),
                ) {
                    Icon(
                        imageVector = Icons.Filled.PictureAsPdf,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = historyStrings.exportWeeklyPdfBtn,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ThreatHistoryBottomSheet(
    incidents: List<ThreatIncidentEntity>,
    language: AppLanguage,
    readOnly: Boolean,
    onDismiss: () -> Unit,
    onUpdateAction: (Long, IncidentActionTaken) -> Unit,
    onSecureShield: (ThreatIncidentEntity, ShieldId) -> Unit,
    onDeleteIncident: (Long) -> Unit,
    onClearHistory: () -> Unit,
    highlightedIncidentId: Long? = null,
    onExportWeeklyPdf: (() -> Unit)? = null,
) {
    val strings = LocalStrings.current
    val historyStrings = strings.threatHistory
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var filter by remember { mutableStateOf(ThreatHistoryFilter.ALL) }

    LaunchedEffect(highlightedIncidentId) {
        if (highlightedIncidentId != null) {
            filter = ThreatHistoryFilter.ALL
        }
    }

    val highlightedIncident = remember(incidents, highlightedIncidentId) {
        highlightedIncidentId?.let { targetId ->
            incidents.firstOrNull { it.id == targetId }
        }
    }

    val filteredIncidents = remember(incidents, filter) {
        when (filter) {
            ThreatHistoryFilter.ALL -> incidents
            ThreatHistoryFilter.PENDING -> incidents.filter { !it.resolved }
            ThreatHistoryFilter.RESOLVED -> incidents.filter { it.resolved }
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Icon(
                        imageVector = Icons.Filled.History,
                        contentDescription = historyStrings.title,
                        tint = MaterialTheme.colorScheme.primary,
                    )
                    Column {
                        Text(
                            text = historyStrings.title,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            text = historyStrings.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                if (incidents.isNotEmpty() && !readOnly) {
                    TextButton(
                        onClick = onClearHistory,
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("threat_history_clear_all_btn"),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteSweep,
                            contentDescription = historyStrings.btnClearAll,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(historyStrings.btnClearAll)
                    }
                }
            }

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                FilterChip(
                    selected = filter == ThreatHistoryFilter.ALL,
                    onClick = { filter = ThreatHistoryFilter.ALL },
                    label = { Text("${historyStrings.filterAll} (${incidents.size})") },
                    modifier = Modifier.testTag("threat_history_filter_all"),
                )
                FilterChip(
                    selected = filter == ThreatHistoryFilter.PENDING,
                    onClick = { filter = ThreatHistoryFilter.PENDING },
                    label = { Text("${historyStrings.filterPending} (${incidents.count { !it.resolved }})") },
                    modifier = Modifier.testTag("threat_history_filter_pending"),
                )
                FilterChip(
                    selected = filter == ThreatHistoryFilter.RESOLVED,
                    onClick = { filter = ThreatHistoryFilter.RESOLVED },
                    label = { Text("${historyStrings.filterResolved} (${incidents.count { it.resolved }})") },
                    modifier = Modifier.testTag("threat_history_filter_resolved"),
                )
            }

            if (onExportWeeklyPdf != null) {
                FilledTonalButton(
                    onClick = onExportWeeklyPdf,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 48.dp)
                        .testTag("sheet_export_weekly_pdf_button"),
                ) {
                    Icon(
                        imageVector = Icons.Filled.PictureAsPdf,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = historyStrings.exportWeeklyPdfBtn,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }

            if (filteredIncidents.isEmpty() && highlightedIncident == null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp)
                        .testTag("threat_history_sheet_empty"),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = Icons.Filled.GppGood,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(30.dp),
                        )
                    }
                    Text(
                        text = historyStrings.emptyTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                    )
                    Text(
                        text = historyStrings.emptySubtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 500.dp)
                        .testTag("threat_history_sheet_list"),
                    contentPadding = PaddingValues(bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    if (highlightedIncident != null) {
                        item(key = "highlighted_incident_detail") {
                            HighlightedIncidentDetailCard(
                                incident = highlightedIncident,
                                language = language,
                                readOnly = readOnly,
                                onSecureShield = {
                                    onSecureShield(highlightedIncident, highlightedIncident.targetShield)
                                },
                                onMarkInspected = {
                                    onUpdateAction(
                                        highlightedIncident.id,
                                        IncidentActionTaken.USER_INSPECTED,
                                    )
                                },
                                onDismissIncident = {
                                    onUpdateAction(
                                        highlightedIncident.id,
                                        IncidentActionTaken.USER_DISMISSED,
                                    )
                                },
                            )
                        }
                    }

                    items(
                        items = filteredIncidents,
                        key = { it.id },
                    ) { incident ->
                        ThreatIncidentHistoryCard(
                            incident = incident,
                            language = language,
                            readOnly = readOnly,
                            isHighlighted = incident.id == highlightedIncidentId,
                            onSecureShield = { onSecureShield(incident, incident.targetShield) },
                            onMarkInspected = {
                                onUpdateAction(incident.id, IncidentActionTaken.USER_INSPECTED)
                            },
                            onDismissIncident = {
                                onUpdateAction(incident.id, IncidentActionTaken.USER_DISMISSED)
                            },
                            onDelete = { onDeleteIncident(incident.id) },
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun HighlightedIncidentDetailCard(
    incident: ThreatIncidentEntity,
    language: AppLanguage,
    readOnly: Boolean,
    onSecureShield: () -> Unit,
    onMarkInspected: () -> Unit,
    onDismissIncident: () -> Unit,
) {
    val strings = LocalStrings.current
    val historyStrings = strings.threatHistory
    val dera3Colors = LocalDera3Colors.current

    val title = LocalizationManager.resolveLocalizedText(language, incident.titleAr, incident.titleEn)
    val message = LocalizationManager.resolveLocalizedText(language, incident.messageAr, incident.messageEn)
    val actionNote = LocalizationManager.resolveLocalizedText(language, incident.actionNoteAr, incident.actionNoteEn)
    val shieldTitle = strings.shieldTitles.getOrElse(incident.targetShield.index) { incident.targetShield.name }
    val action = incident.parsedAction
    val actionLabel = localizedActionLabel(action, historyStrings)
    val actionColor = actionAccentColor(action)
    val severity = incident.parsedSeverity
    val severityColor = if (severity == ThreatSeverity.MEDIUM) dera3Colors.caution else dera3Colors.danger
    val severityText = when (severity) {
        ThreatSeverity.CRITICAL -> strings.phishingSeverityCritical
        ThreatSeverity.HIGH -> strings.phishingSeverityHigh
        ThreatSeverity.MEDIUM -> strings.phishingSeverityMedium
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("highlighted_incident_detail_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
        ),
        border = BorderStroke(2.dp, MaterialTheme.colorScheme.primary),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.primary,
                ) {
                    Text(
                        text = historyStrings.fromNotificationBadge,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    )
                }
                Surface(
                    shape = RoundedCornerShape(50),
                    color = severityColor.copy(alpha = 0.16f),
                ) {
                    Text(
                        text = severityText,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = severityColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                    )
                }
            }

            Text(
                text = historyStrings.selectedDetailsTitle,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(
                    imageVector = incidentCategoryIcon(incident.parsedCategory),
                    contentDescription = title,
                    tint = severityColor,
                    modifier = Modifier.size(22.dp),
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
            }

            if (message.isNotBlank()) {
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )
            }

            if (incident.indicator.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        text = incident.indicator,
                        style = MaterialTheme.typography.labelMedium.copy(fontFamily = MonoFontFamily),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "${historyStrings.shieldLabel} $shieldTitle",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    text = "${historyStrings.detectedAtLabel} ${formatIncidentTimestamp(incident.detectedAtMillis)}",
                    style = MaterialTheme.typography.labelMedium.copy(fontFamily = MonoFontFamily),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = actionColor.copy(alpha = 0.14f),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                    Text(
                        text = "${historyStrings.actionLabel} $actionLabel",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = actionColor,
                    )
                    if (actionNote.isNotBlank()) {
                        Text(
                            text = actionNote,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            if (!readOnly) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Button(
                        onClick = onSecureShield,
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("highlighted_incident_secure_shield"),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Shield,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(historyStrings.btnSecureShield)
                    }

                    if (action != IncidentActionTaken.USER_INSPECTED) {
                        FilledTonalButton(
                            onClick = onMarkInspected,
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("highlighted_incident_mark_inspected"),
                        ) {
                            Text(historyStrings.btnMarkInspected)
                        }
                    }

                    if (action != IncidentActionTaken.USER_DISMISSED) {
                        OutlinedButton(
                            onClick = onDismissIncident,
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("highlighted_incident_dismiss"),
                        ) {
                            Text(historyStrings.btnDismiss)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ThreatIncidentHistoryCard(
    incident: ThreatIncidentEntity,
    language: AppLanguage,
    readOnly: Boolean,
    isHighlighted: Boolean = false,
    onSecureShield: () -> Unit,
    onMarkInspected: () -> Unit,
    onDismissIncident: () -> Unit,
    onDelete: () -> Unit,
) {
    val strings = LocalStrings.current
    val historyStrings = strings.threatHistory
    val dera3Colors = LocalDera3Colors.current

    val title = LocalizationManager.resolveLocalizedText(language, incident.titleAr, incident.titleEn)
    val message = LocalizationManager.resolveLocalizedText(language, incident.messageAr, incident.messageEn)
    val actionNote = LocalizationManager.resolveLocalizedText(language, incident.actionNoteAr, incident.actionNoteEn)
    val action = incident.parsedAction
    val actionLabel = localizedActionLabel(action, historyStrings)
    val actionColor = actionAccentColor(action)

    val severity = incident.parsedSeverity
    val severityText = when (severity) {
        ThreatSeverity.CRITICAL -> strings.phishingSeverityCritical
        ThreatSeverity.HIGH -> strings.phishingSeverityHigh
        ThreatSeverity.MEDIUM -> strings.phishingSeverityMedium
    }
    val severityColor = if (severity == ThreatSeverity.MEDIUM) dera3Colors.caution else dera3Colors.danger

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("threat_incident_item_${incident.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (incident.resolved) {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        border = BorderStroke(
            width = if (isHighlighted) 2.dp else 1.dp,
            color = when {
                isHighlighted -> MaterialTheme.colorScheme.primary
                incident.resolved -> actionColor.copy(alpha = 0.35f)
                else -> severityColor.copy(alpha = 0.5f)
            },
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(
                    imageVector = incidentCategoryIcon(incident.parsedCategory),
                    contentDescription = title,
                    tint = severityColor,
                    modifier = Modifier.size(20.dp),
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                Surface(
                    shape = RoundedCornerShape(50),
                    color = severityColor.copy(alpha = 0.14f),
                ) {
                    Text(
                        text = severityText,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = severityColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                    )
                }
                if (!readOnly) {
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("delete_incident_${incident.id}"),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteOutline,
                            contentDescription = historyStrings.btnDelete,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp),
                        )
                    }
                }
            }

            if (message.isNotBlank()) {
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (incident.indicator.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                    ) {
                        Text(
                            text = incident.indicator,
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        )
                    }
                }
                Text(
                    text = formatIncidentTimestamp(incident.detectedAtMillis),
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            // Action Taken Status Banner
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = actionColor.copy(alpha = 0.12f),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("incident_action_badge_${incident.id}"),
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        imageVector = if (incident.resolved) Icons.Filled.CheckCircle else Icons.Filled.WarningAmber,
                        contentDescription = actionLabel,
                        tint = actionColor,
                        modifier = Modifier.size(18.dp),
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${historyStrings.actionLabel} $actionLabel",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = actionColor,
                        )
                        if (actionNote.isNotBlank()) {
                            Text(
                                text = actionNote,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }

            // Action Controls
            if (!readOnly) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Button(
                        onClick = onSecureShield,
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("incident_secure_shield_${incident.id}"),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Shield,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(historyStrings.btnSecureShield)
                    }

                    if (action != IncidentActionTaken.USER_INSPECTED) {
                        FilledTonalButton(
                            onClick = onMarkInspected,
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("incident_mark_inspected_${incident.id}"),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Visibility,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(historyStrings.btnMarkInspected)
                        }
                    }

                    if (action != IncidentActionTaken.USER_DISMISSED) {
                        OutlinedButton(
                            onClick = onDismissIncident,
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("incident_dismiss_${incident.id}"),
                        ) {
                            Text(historyStrings.btnDismiss)
                        }
                    }
                }
            }
        }
    }
}

private fun localizedActionLabel(
    action: IncidentActionTaken,
    strings: ThreatHistoryStrings,
): String = when (action) {
    IncidentActionTaken.DETECTED_LOGGED -> strings.actionDetected
    IncidentActionTaken.BLOCKED_AUTO -> strings.actionBlocked
    IncidentActionTaken.USER_INSPECTED -> strings.actionInspected
    IncidentActionTaken.SHIELD_SECURED -> strings.actionSecured
    IncidentActionTaken.USER_DISMISSED -> strings.actionDismissed
}

@Composable
private fun actionAccentColor(action: IncidentActionTaken): Color {
    val dera3Colors = LocalDera3Colors.current
    return when (action) {
        IncidentActionTaken.DETECTED_LOGGED -> dera3Colors.danger
        IncidentActionTaken.BLOCKED_AUTO -> MaterialTheme.colorScheme.primary
        IncidentActionTaken.USER_INSPECTED -> dera3Colors.caution
        IncidentActionTaken.SHIELD_SECURED -> dera3Colors.safe
        IncidentActionTaken.USER_DISMISSED -> MaterialTheme.colorScheme.onSurfaceVariant
    }
}

private fun incidentCategoryIcon(category: PhishingCategory): ImageVector = when (category) {
    PhishingCategory.LINK_PHISHING -> Icons.Filled.Link
    PhishingCategory.BANK_IMPERSONATION -> Icons.AutoMirrored.Filled.PhoneMissed
    PhishingCategory.FAKE_APP -> Icons.Filled.AppBlocking
    PhishingCategory.OTP_SCAM -> Icons.Filled.Security
    PhishingCategory.SMS_DELIVERY -> Icons.Filled.SmsFailed
}

private fun formatIncidentTimestamp(millis: Long): String {
    if (millis <= 0L) return ""
    return SimpleDateFormat("dd/MM HH:mm", Locale.US).format(Date(millis))
}
