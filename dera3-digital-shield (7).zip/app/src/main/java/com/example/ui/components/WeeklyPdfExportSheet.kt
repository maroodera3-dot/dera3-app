package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.IncidentActionTaken
import com.example.data.model.ThreatSeverity
import com.example.domain.ExportedPdfResult
import com.example.domain.WeeklyRoomSummaryReport
import com.example.domain.WeeklySummaryPdfExporter
import com.example.localization.AppLanguage
import com.example.localization.LocalStrings
import com.example.localization.LocalizationManager
import com.example.ui.theme.LocalDera3Colors
import com.example.ui.theme.MonoFontFamily
import kotlin.math.max
import kotlin.math.roundToInt

sealed interface WeeklyPdfExportState {
    data object Idle : WeeklyPdfExportState
    data object Exporting : WeeklyPdfExportState
    data class Ready(
        val report: WeeklyRoomSummaryReport,
        val exportedPdf: ExportedPdfResult,
    ) : WeeklyPdfExportState

    data class Error(val message: String) : WeeklyPdfExportState
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun WeeklyPdfExportBottomSheet(
    exportState: WeeklyPdfExportState,
    language: AppLanguage,
    onDismiss: () -> Unit,
    onSharePdf: (ExportedPdfResult, WeeklyRoomSummaryReport) -> Unit,
    onOpenPdf: (ExportedPdfResult) -> Unit,
) {
    if (exportState is WeeklyPdfExportState.Idle) return

    val strings = LocalStrings.current
    val historyStrings = strings.threatHistory
    val weeklyStrings = strings.weeklyStats
    val dera3Colors = LocalDera3Colors.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp)
                .padding(bottom = 18.dp)
                .testTag("weekly_pdf_export_sheet"),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            when (exportState) {
                WeeklyPdfExportState.Idle -> Unit
                WeeklyPdfExportState.Exporting -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp)
                            .testTag("weekly_pdf_exporting_indicator"),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        CircularProgressIndicator()
                        Text(
                            text = historyStrings.exportingWeeklyPdf,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                }
                is WeeklyPdfExportState.Error -> {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = dera3Colors.dangerContainer,
                        border = BorderStroke(1.dp, dera3Colors.danger.copy(alpha = 0.4f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("weekly_pdf_export_error"),
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Text(
                                text = historyStrings.pdfExportFailed,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = dera3Colors.danger,
                            )
                            Text(
                                text = exportState.message,
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
                is WeeklyPdfExportState.Ready -> {
                    val report = exportState.report
                    val pdf = exportState.exportedPdf
                    val fileSizeKb = max(1L, (pdf.byteCount + 1023L) / 1024L).toInt()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                imageVector = Icons.Filled.PictureAsPdf,
                                contentDescription = historyStrings.pdfSheetTitle,
                                tint = MaterialTheme.colorScheme.primary,
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = historyStrings.pdfSheetTitle,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                            )
                            Text(
                                text = historyStrings.pdfSheetSubtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }

                    // Scrollable PDF-like Summary Card Preview
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 460.dp)
                            .testTag("weekly_pdf_summary_card_preview"),
                        contentPadding = PaddingValues(bottom = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        // Document Header Card
                        item(key = "pdf_card_header") {
                            Card(
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                                ),
                                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(50),
                                            color = MaterialTheme.colorScheme.primary,
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(5.dp),
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.VerifiedUser,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.onPrimary,
                                                    modifier = Modifier.size(14.dp),
                                                )
                                                Text(
                                                    text = historyStrings.pdfSourceBadge,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onPrimary,
                                                )
                                            }
                                        }
                                        Text(
                                            text = strings.appName,
                                            style = MaterialTheme.typography.labelLarge.copy(fontFamily = MonoFontFamily),
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.primary,
                                        )
                                    }

                                    Text(
                                        text = LocalizationManager.formatString(
                                            historyStrings.pdfPeriodFormat,
                                            report.periodStartLabel,
                                            report.periodEndLabel,
                                        ),
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                    )
                                    Text(
                                        text = "${report.accountLabel} • " + LocalizationManager.formatString(
                                            historyStrings.pdfGeneratedAtFormat,
                                            report.generatedAtLabel,
                                        ),
                                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                        }

                        // 4 KPI Summary Grid
                        item(key = "pdf_card_kpis") {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                PdfMetricTile(
                                    value = "${report.totalIncidents}",
                                    label = weeklyStrings.totalThreatsLabel,
                                    accent = MaterialTheme.colorScheme.primary,
                                    container = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                                    modifier = Modifier.weight(1f),
                                )
                                PdfMetricTile(
                                    value = "${report.criticalCount + report.highCount}",
                                    label = weeklyStrings.criticalHighLabel,
                                    accent = dera3Colors.danger,
                                    container = dera3Colors.dangerContainer,
                                    modifier = Modifier.weight(1f),
                                )
                                PdfMetricTile(
                                    value = "${report.resolvedCount}",
                                    label = historyStrings.filterResolved,
                                    accent = dera3Colors.safe,
                                    container = dera3Colors.safeContainer,
                                    modifier = Modifier.weight(1f),
                                )
                                PdfMetricTile(
                                    value = "${report.resolutionRatePercent}%",
                                    label = weeklyStrings.resolvedRateLabel,
                                    accent = dera3Colors.caution,
                                    container = dera3Colors.cautionContainer,
                                    modifier = Modifier.weight(1f),
                                )
                            }
                        }

                        // 7-Day Activity Mini Bars
                        item(key = "pdf_card_daily") {
                            val maxDay = max(1, report.dailyStats.maxOfOrNull { it.totalCount } ?: 1)
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                ) {
                                    Text(
                                        text = historyStrings.pdfDailyTitle,
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.Bottom,
                                    ) {
                                        report.dailyStats.forEach { day ->
                                            val heightFraction = if (day.totalCount == 0) 0.08f else (day.totalCount.toFloat() / maxDay).coerceIn(0.18f, 1f)
                                            Column(
                                                modifier = Modifier.weight(1f),
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.spacedBy(4.dp),
                                            ) {
                                                Text(
                                                    text = "${day.totalCount}",
                                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                )
                                                Box(
                                                    modifier = Modifier
                                                        .height(48.dp)
                                                        .fillMaxWidth(),
                                                    contentAlignment = Alignment.BottomCenter,
                                                ) {
                                                    Box(
                                                        modifier = Modifier
                                                            .width(14.dp)
                                                            .height((48f * heightFraction).dp)
                                                            .clip(RoundedCornerShape(4.dp))
                                                            .background(
                                                                if (day.criticalCount > 0) {
                                                                    dera3Colors.danger
                                                                } else if (day.totalCount > 0) {
                                                                    MaterialTheme.colorScheme.primary
                                                                } else {
                                                                    MaterialTheme.colorScheme.surfaceVariant
                                                                }
                                                            ),
                                                    )
                                                }
                                                Text(
                                                    text = day.dayLabelShort,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Categories & Actions Taken Summary
                        if (report.categoryStats.isNotEmpty() || report.actionStats.isNotEmpty()) {
                            item(key = "pdf_card_breakdown") {
                                Card(
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        if (report.categoryStats.isNotEmpty()) {
                                            Text(
                                                text = historyStrings.pdfCategoriesTitle,
                                                style = MaterialTheme.typography.labelLarge,
                                                fontWeight = FontWeight.Bold,
                                            )
                                            report.categoryStats.forEach { stat ->
                                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                    ) {
                                                        Text(
                                                            text = WeeklySummaryPdfExporter.categoryDisplayName(stat.category, strings),
                                                            style = MaterialTheme.typography.labelMedium,
                                                        )
                                                        Text(
                                                            text = "${stat.count} (${stat.percentage.roundToInt()}%)",
                                                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                                                            fontWeight = FontWeight.Bold,
                                                        )
                                                    }
                                                    LinearProgressIndicator(
                                                        progress = { (stat.percentage / 100f).coerceIn(0f, 1f) },
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .height(6.dp)
                                                            .clip(RoundedCornerShape(3.dp)),
                                                    )
                                                }
                                            }
                                        }

                                        if (report.actionStats.isNotEmpty()) {
                                            Text(
                                                text = historyStrings.pdfActionsTitle,
                                                style = MaterialTheme.typography.labelLarge,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(top = 4.dp),
                                            )
                                            FlowRow(
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                verticalArrangement = Arrangement.spacedBy(6.dp),
                                            ) {
                                                report.actionStats.forEach { stat ->
                                                    val actionName = WeeklySummaryPdfExporter.actionDisplayName(stat.action, strings)
                                                    Surface(
                                                        shape = RoundedCornerShape(50),
                                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                                    ) {
                                                        Text(
                                                            text = "$actionName: ${stat.count}",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Weekly Room Incidents List (or real zero-incident status)
                        if (report.incidents.isEmpty()) {
                            item(key = "pdf_card_no_incidents") {
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = dera3Colors.safeContainer,
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Shield,
                                            contentDescription = null,
                                            tint = dera3Colors.safe,
                                        )
                                        Text(
                                            text = historyStrings.pdfNoIncidents,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.SemiBold,
                                            color = dera3Colors.safe,
                                        )
                                    }
                                }
                            }
                        } else {
                            item(key = "pdf_card_incidents_header") {
                                Text(
                                    text = historyStrings.pdfIncidentsTitle,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                            items(
                                items = report.incidents.take(8),
                                key = { "pdf_preview_${it.id}" },
                            ) { incident ->
                                val title = LocalizationManager.resolveLocalizedText(
                                    language,
                                    incident.titleAr,
                                    incident.titleEn,
                                )
                                val actionName = WeeklySummaryPdfExporter.actionDisplayName(incident.parsedAction, strings)
                                val sevColor = when (incident.parsedSeverity) {
                                    ThreatSeverity.CRITICAL -> dera3Colors.danger
                                    ThreatSeverity.HIGH -> dera3Colors.caution
                                    ThreatSeverity.MEDIUM -> MaterialTheme.colorScheme.primary
                                }
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .clip(CircleShape)
                                                .background(sevColor),
                                        )
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = title,
                                                style = MaterialTheme.typography.labelLarge,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                            )
                                            Text(
                                                text = actionName,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (incident.parsedAction == IncidentActionTaken.DETECTED_LOGGED) {
                                                    dera3Colors.danger
                                                } else {
                                                    dera3Colors.safe
                                                },
                                            )
                                        }
                                        if (incident.indicator.isNotBlank()) {
                                            Text(
                                                text = incident.indicator,
                                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.width(105.dp),
                                                textAlign = TextAlign.End,
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Exported PDF File Metadata Pill
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = dera3Colors.safeContainer.copy(alpha = 0.65f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("weekly_pdf_file_metadata"),
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = null,
                                tint = dera3Colors.safe,
                                modifier = Modifier.size(18.dp),
                            )
                            Text(
                                text = LocalizationManager.formatString(
                                    historyStrings.pdfFileMetaFormat,
                                    pdf.fileName,
                                    fileSizeKb,
                                    pdf.pageCount,
                                ),
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }

                    // Action Buttons: Share PDF & Open PDF
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        OutlinedButton(
                            onClick = { onOpenPdf(pdf) },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                                .testTag("open_weekly_pdf_button"),
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = historyStrings.openPdfBtn,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }

                        Button(
                            onClick = { onSharePdf(pdf, report) },
                            modifier = Modifier
                                .weight(1.25f)
                                .heightIn(min = 48.dp)
                                .testTag("share_weekly_pdf_button"),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Share,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = historyStrings.sharePdfBtn,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PdfMetricTile(
    value: String,
    label: String,
    accent: Color,
    container: Color,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = container,
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily),
                fontWeight = FontWeight.ExtraBold,
                color = accent,
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
            )
        }
    }
}
