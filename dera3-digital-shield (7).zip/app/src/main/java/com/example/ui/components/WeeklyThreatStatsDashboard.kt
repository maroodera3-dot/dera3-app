package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.PhoneMissed
import androidx.compose.material.icons.filled.AppBlocking
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.DonutLarge
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SmsFailed
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.PhishingCategory
import com.example.data.model.PhishingNotificationItem
import com.example.data.model.ShieldId
import com.example.data.model.UiState
import com.example.domain.CategoryBreakdownSlice
import com.example.domain.DailyThreatBucket
import com.example.domain.WeeklyThreatAggregator
import com.example.domain.WeeklyThreatSummary
import com.example.localization.AppLanguage
import com.example.localization.LocalStrings
import com.example.localization.LocalizationManager
import com.example.localization.WeeklyStatsStrings
import com.example.ui.theme.LocalDera3Colors
import com.example.ui.theme.MonoFontFamily
import com.example.ui.theme.VioletThreat
import com.example.ui.theme.VioletThreatDark
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt

private enum class WeeklyChartMode {
    DAILY_BAR,
    CATEGORY_DONUT,
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WeeklyThreatStatsDashboard(
    phishingNotificationsState: UiState<List<PhishingNotificationItem>>,
    language: AppLanguage,
    onFocusShield: (ShieldId) -> Unit,
    modifier: Modifier = Modifier,
) {
    val strings = LocalStrings.current
    val weeklyStrings = strings.weeklyStats
    val dera3Colors = LocalDera3Colors.current

    val liveItems = remember(phishingNotificationsState) {
        (phishingNotificationsState as? UiState.Success)?.data.orEmpty()
    }

    var useSamplePreview by remember { mutableStateOf(false) }
    var chartMode by remember { mutableStateOf(WeeklyChartMode.DAILY_BAR) }

    val effectiveItems = remember(liveItems, useSamplePreview) {
        if (useSamplePreview) {
            WeeklyThreatAggregator.buildSamplePreviewItems()
        } else {
            liveItems
        }
    }

    val summary = remember(effectiveItems, language, useSamplePreview) {
        WeeklyThreatAggregator.buildWeeklySummary(
            items = effectiveItems,
            language = language,
            isSamplePreview = useSamplePreview,
        )
    }

    var selectedDayIndex by remember(summary.dailyBuckets) {
        mutableIntStateOf(summary.peakDay?.dayIndex ?: 6)
    }
    var selectedCategory by remember(summary.categoryBreakdown) {
        mutableStateOf(summary.categoryBreakdown.firstOrNull()?.category)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("weekly_threat_stats_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Filled.BarChart,
                        contentDescription = weeklyStrings.title,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp),
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = weeklyStrings.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = weeklyStrings.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // Data Source Mode Toggle (Live Data vs Sample Preview)
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                FilterChip(
                    selected = !useSamplePreview,
                    onClick = { useSamplePreview = false },
                    label = { Text(weeklyStrings.liveSourceChip) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Filled.Timeline,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                        )
                    },
                    modifier = Modifier.testTag("weekly_stats_live_chip"),
                )
                FilterChip(
                    selected = useSamplePreview,
                    onClick = { useSamplePreview = true },
                    label = { Text(weeklyStrings.samplePreviewChip) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Filled.PieChart,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = dera3Colors.cautionContainer,
                        selectedLabelColor = dera3Colors.caution,
                        selectedLeadingIconColor = dera3Colors.caution,
                    ),
                    modifier = Modifier.testTag("weekly_stats_sample_chip"),
                )
            }

            AnimatedVisibility(visible = useSamplePreview) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = dera3Colors.cautionContainer,
                    border = BorderStroke(1.dp, dera3Colors.caution.copy(alpha = 0.4f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("weekly_stats_sample_banner"),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Info,
                            contentDescription = null,
                            tint = dera3Colors.caution,
                            modifier = Modifier.size(18.dp),
                        )
                        Text(
                            text = weeklyStrings.samplePreviewBanner,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                }
            }

            // 3 KPI Summary Pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                WeeklyKpiTile(
                    label = weeklyStrings.totalThreatsLabel,
                    value = "${summary.totalThreats}",
                    accentColor = MaterialTheme.colorScheme.primary,
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("weekly_kpi_total"),
                )
                WeeklyKpiTile(
                    label = weeklyStrings.criticalHighLabel,
                    value = "${summary.criticalCount + summary.highCount}",
                    accentColor = dera3Colors.danger,
                    containerColor = dera3Colors.dangerContainer,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("weekly_kpi_critical_high"),
                )
                WeeklyKpiTile(
                    label = weeklyStrings.resolvedRateLabel,
                    value = "${summary.resolutionRatePercent}%",
                    accentColor = dera3Colors.safe,
                    containerColor = dera3Colors.safeContainer,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("weekly_kpi_resolved_rate"),
                )
            }

            // Chart Mode Switcher Tabs
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    ChartModeTab(
                        selected = chartMode == WeeklyChartMode.DAILY_BAR,
                        label = weeklyStrings.weeklyTrendTab,
                        icon = Icons.Filled.BarChart,
                        onClick = { chartMode = WeeklyChartMode.DAILY_BAR },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("weekly_stats_tab_trend"),
                    )
                    ChartModeTab(
                        selected = chartMode == WeeklyChartMode.CATEGORY_DONUT,
                        label = weeklyStrings.categoryBreakdownTab,
                        icon = Icons.Filled.DonutLarge,
                        onClick = { chartMode = WeeklyChartMode.CATEGORY_DONUT },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("weekly_stats_tab_categories"),
                    )
                }
            }

            // Chart Body or Empty State
            if (summary.totalThreats == 0) {
                WeeklyStatsEmptyState(
                    weeklyStrings = weeklyStrings,
                    onEnableSamplePreview = { useSamplePreview = true },
                )
            } else {
                AnimatedContent(
                    targetState = chartMode,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "weekly_chart_mode",
                ) { activeMode ->
                    when (activeMode) {
                        WeeklyChartMode.DAILY_BAR -> {
                            WeeklyStackedBarChartSection(
                                summary = summary,
                                selectedDayIndex = selectedDayIndex.coerceIn(0, summary.dailyBuckets.lastIndex),
                                onSelectDay = { selectedDayIndex = it },
                                weeklyStrings = weeklyStrings,
                                onFocusShield = onFocusShield,
                            )
                        }
                        WeeklyChartMode.CATEGORY_DONUT -> {
                            WeeklyCategoryDonutSection(
                                summary = summary,
                                selectedCategory = selectedCategory ?: summary.categoryBreakdown.firstOrNull()?.category,
                                onSelectCategory = { selectedCategory = it },
                                weeklyStrings = weeklyStrings,
                                onFocusShield = onFocusShield,
                            )
                        }
                    }
                }

                // Weekly Insights Footer (Top Category + Peak Day)
                WeeklyInsightsFooter(
                    summary = summary,
                    weeklyStrings = weeklyStrings,
                )
            }
        }
    }
}

@Composable
private fun WeeklyKpiTile(
    label: String,
    value: String,
    accentColor: Color,
    containerColor: Color,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = containerColor,
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(fontFamily = MonoFontFamily),
                fontWeight = FontWeight.ExtraBold,
                color = accentColor,
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
private fun ChartModeTab(
    selected: Boolean,
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (selected) MaterialTheme.colorScheme.surface else Color.Transparent,
        tonalElevation = if (selected) 2.dp else 0.dp,
        modifier = modifier
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp),
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun WeeklyStatsEmptyState(
    weeklyStrings: WeeklyStatsStrings,
    onEnableSamplePreview: () -> Unit,
) {
    val dera3Colors = LocalDera3Colors.current
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = dera3Colors.safeContainer.copy(alpha = 0.55f),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("weekly_stats_empty_state"),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(dera3Colors.safe.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Filled.Shield,
                    contentDescription = null,
                    tint = dera3Colors.safe,
                    modifier = Modifier.size(28.dp),
                )
            }
            Text(
                text = weeklyStrings.chartEmptyTitle,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
            )
            Text(
                text = weeklyStrings.chartEmptySubtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            FilledTonalButton(
                onClick = onEnableSamplePreview,
                modifier = Modifier
                    .heightIn(min = 48.dp)
                    .testTag("weekly_stats_empty_preview_btn"),
            ) {
                Icon(
                    imageVector = Icons.Filled.BarChart,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(6.dp))
                Text(weeklyStrings.samplePreviewChip)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun WeeklyStackedBarChartSection(
    summary: WeeklyThreatSummary,
    selectedDayIndex: Int,
    onSelectDay: (Int) -> Unit,
    weeklyStrings: WeeklyStatsStrings,
    onFocusShield: (ShieldId) -> Unit,
) {
    val dera3Colors = LocalDera3Colors.current
    val criticalColor = dera3Colors.danger
    val highColor = dera3Colors.caution
    val mediumColor = MaterialTheme.colorScheme.primary
    val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)
    val cursorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)
    val labelColor = MaterialTheme.colorScheme.onSurfaceVariant
    val textMeasurer = rememberTextMeasurer()

    var revealTriggered by remember { mutableStateOf(false) }
    LaunchedEffect(summary.totalThreats, summary.isUsingSamplePreview) {
        revealTriggered = true
    }
    val animationProgress by animateFloatAsState(
        targetValue = if (revealTriggered) 1f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow,
        ),
        label = "bar_reveal",
    )

    val buckets = summary.dailyBuckets
    val rawMax = buckets.maxOfOrNull { it.totalCount } ?: 1
    val yAxisMax = max(2, ceil(rawMax / 2.0).toInt() * 2)

    val axisTextStyle = MaterialTheme.typography.labelSmall.copy(
        fontFamily = MonoFontFamily,
        color = labelColor,
    )

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Recharts-style Interactive Tooltip Card for selected day
        val selectedBucket = buckets.getOrNull(selectedDayIndex)
        if (selectedBucket != null) {
            DayTooltipCard(
                bucket = selectedBucket,
                weeklyStrings = weeklyStrings,
                criticalColor = criticalColor,
                highColor = highColor,
                mediumColor = mediumColor,
                onFocusShield = onFocusShield,
            )
        }

        // Canvas Stacked Bar Chart
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(190.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.28f))
                .padding(horizontal = 12.dp, vertical = 14.dp)
                .testTag("weekly_stacked_bar_canvas"),
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(buckets) {
                        detectTapGestures { tapOffset ->
                            val yLabelReserve = 28.dp.toPx()
                            val chartWidth = (size.width - yLabelReserve).coerceAtLeast(1f)
                            val relX = (tapOffset.x - yLabelReserve).coerceIn(0f, chartWidth - 1f)
                            val tappedIndex = ((relX / chartWidth) * buckets.size)
                                .toInt()
                                .coerceIn(0, buckets.lastIndex)
                            onSelectDay(tappedIndex)
                        }
                    },
            ) {
                val yLabelWidth = 28.dp.toPx()
                val topPad = 8.dp.toPx()
                val bottomPad = 6.dp.toPx()
                val chartLeft = yLabelWidth
                val chartWidth = (size.width - chartLeft).coerceAtLeast(1f)
                val chartHeight = (size.height - topPad - bottomPad).coerceAtLeast(1f)

                val dashEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
                val gridSteps = 2
                for (step in 0..gridSteps) {
                    val fraction = step.toFloat() / gridSteps
                    val y = topPad + chartHeight * (1f - fraction)
                    drawLine(
                        color = gridColor,
                        start = Offset(chartLeft, y),
                        end = Offset(size.width, y),
                        strokeWidth = 1.dp.toPx(),
                        pathEffect = if (step == 0) null else dashEffect,
                    )
                    val tickValue = ((yAxisMax * step) / gridSteps)
                    val measured = textMeasurer.measure(
                        text = "$tickValue",
                        style = axisTextStyle,
                    )
                    drawText(
                        textLayoutResult = measured,
                        topLeft = Offset(
                            x = (yLabelWidth - measured.size.width - 6.dp.toPx()).coerceAtLeast(0f),
                            y = (y - measured.size.height / 2f).coerceIn(0f, size.height - measured.size.height),
                        ),
                    )
                }

                val slotWidth = chartWidth / buckets.size
                val barWidth = (slotWidth * 0.52f).coerceIn(14.dp.toPx(), 32.dp.toPx())

                buckets.forEachIndexed { index, bucket ->
                    val slotLeft = chartLeft + index * slotWidth
                    val barLeft = slotLeft + (slotWidth - barWidth) / 2f

                    // Selected cursor highlight (Recharts Tooltip cursor style)
                    if (index == selectedDayIndex) {
                        drawRoundRect(
                            color = cursorColor,
                            topLeft = Offset(slotLeft + 2.dp.toPx(), topPad),
                            size = Size((slotWidth - 4.dp.toPx()).coerceAtLeast(1f), chartHeight),
                            cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx()),
                        )
                    }

                    if (bucket.totalCount > 0) {
                        val anim = animationProgress.coerceIn(0f, 1f)
                        val medH = (bucket.mediumCount.toFloat() / yAxisMax) * chartHeight * anim
                        val highH = (bucket.highCount.toFloat() / yAxisMax) * chartHeight * anim
                        val critH = (bucket.criticalCount.toFloat() / yAxisMax) * chartHeight * anim

                        var currentBottom = topPad + chartHeight

                        if (medH > 0f) {
                            drawRoundRect(
                                color = mediumColor,
                                topLeft = Offset(barLeft, currentBottom - medH),
                                size = Size(barWidth, medH),
                                cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx()),
                            )
                            currentBottom -= medH
                        }
                        if (highH > 0f) {
                            drawRoundRect(
                                color = highColor,
                                topLeft = Offset(barLeft, currentBottom - highH),
                                size = Size(barWidth, highH),
                                cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx()),
                            )
                            currentBottom -= highH
                        }
                        if (critH > 0f) {
                            drawRoundRect(
                                color = criticalColor,
                                topLeft = Offset(barLeft, currentBottom - critH),
                                size = Size(barWidth, critH),
                                cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx()),
                            )
                        }
                    }
                }
            }
        }

        // Interactive Day Selector Labels (Accessible >=48dp touch height)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 28.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            buckets.forEachIndexed { idx, bucket ->
                val isSelected = idx == selectedDayIndex
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) {
                        MaterialTheme.colorScheme.primaryContainer
                    } else {
                        Color.Transparent
                    },
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onSelectDay(idx) }
                        .testTag("weekly_day_selector_$idx"),
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 6.dp, horizontal = 2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Text(
                            text = bucket.dayLabelShort,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = "${bucket.totalCount}",
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                            color = if (isSelected) {
                                MaterialTheme.colorScheme.onPrimaryContainer
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                            },
                        )
                    }
                }
            }
        }

        // Severity Legend
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            LegendDot(color = criticalColor, label = weeklyStrings.severityCritical)
            LegendDot(color = highColor, label = weeklyStrings.severityHigh)
            LegendDot(color = mediumColor, label = weeklyStrings.severityMedium)
        }

        Text(
            text = weeklyStrings.tapDayHint,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DayTooltipCard(
    bucket: DailyThreatBucket,
    weeklyStrings: WeeklyStatsStrings,
    criticalColor: Color,
    highColor: Color,
    mediumColor: Color,
    onFocusShield: (ShieldId) -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("weekly_day_tooltip_card"),
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = LocalizationManager.formatString(
                        weeklyStrings.tooltipDayFormat,
                        bucket.dayLabelShort,
                        bucket.dayDateLabel,
                    ),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                )
                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.primaryContainer,
                ) {
                    Text(
                        text = LocalizationManager.formatString(
                            weeklyStrings.tooltipCountFormat,
                            bucket.totalCount,
                        ),
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    )
                }
            }

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                if (bucket.criticalCount > 0) {
                    SeverityCountBadge(
                        label = weeklyStrings.severityCritical,
                        count = bucket.criticalCount,
                        color = criticalColor,
                    )
                }
                if (bucket.highCount > 0) {
                    SeverityCountBadge(
                        label = weeklyStrings.severityHigh,
                        count = bucket.highCount,
                        color = highColor,
                    )
                }
                if (bucket.mediumCount > 0) {
                    SeverityCountBadge(
                        label = weeklyStrings.severityMedium,
                        count = bucket.mediumCount,
                        color = mediumColor,
                    )
                }
                bucket.dominantCategory?.let { dominant ->
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = MaterialTheme.colorScheme.surface,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .clickable { onFocusShield(dominant.targetShield) },
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            Icon(
                                imageVector = categoryIcon(dominant),
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp),
                            )
                            Text(
                                text = categoryLabel(dominant, weeklyStrings),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SeverityCountBadge(
    label: String,
    count: Int,
    color: Color,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color),
        )
        Text(
            text = "$label: $count",
            style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
private fun LegendDot(
    color: Color,
    label: String,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color),
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun WeeklyCategoryDonutSection(
    summary: WeeklyThreatSummary,
    selectedCategory: PhishingCategory?,
    onSelectCategory: (PhishingCategory) -> Unit,
    weeklyStrings: WeeklyStatsStrings,
    onFocusShield: (ShieldId) -> Unit,
) {
    val slices = summary.categoryBreakdown
    val activeSlice = slices.firstOrNull { it.category == selectedCategory } ?: slices.firstOrNull()

    var revealTriggered by remember { mutableStateOf(false) }
    LaunchedEffect(summary.totalThreats, summary.isUsingSamplePreview) {
        revealTriggered = true
    }
    val sweepProgress by animateFloatAsState(
        targetValue = if (revealTriggered) 1f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessLow,
        ),
        label = "donut_sweep",
    )

    val sliceColors = slices.associate { slice ->
        slice.category to categoryColor(slice.category)
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
            val useSideBySide = maxWidth >= 460.dp

            val donutContent: @Composable () -> Unit = {
                Box(
                    modifier = Modifier
                        .size(176.dp)
                        .testTag("weekly_category_donut_canvas"),
                    contentAlignment = Alignment.Center,
                ) {
                    val trackColor = MaterialTheme.colorScheme.surfaceVariant
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(slices) {
                                detectTapGestures { tapOffset ->
                                    val center = Offset(size.width / 2f, size.height / 2f)
                                    val dx = tapOffset.x - center.x
                                    val dy = tapOffset.y - center.y
                                    val dist = hypot(dx, dy)
                                    val outerR = minOf(size.width, size.height) / 2f
                                    if (dist in (outerR * 0.35f)..outerR) {
                                        var angleDeg = (atan2(dy, dx) * 180.0 / PI).toFloat() + 90f
                                        if (angleDeg < 0f) angleDeg += 360f
                                        var cumulative = 0f
                                        for (slice in slices) {
                                            val sweep = (slice.percentage / 100f) * 360f
                                            if (angleDeg in cumulative..(cumulative + sweep)) {
                                                onSelectCategory(slice.category)
                                                break
                                            }
                                            cumulative += sweep
                                        }
                                    }
                                }
                            },
                    ) {
                        val baseStroke = 26.dp.toPx()
                        val selectedStroke = 32.dp.toPx()
                        val inset = selectedStroke / 2f + 2.dp.toPx()
                        val arcSize = Size(
                            width = (size.width - inset * 2f).coerceAtLeast(1f),
                            height = (size.height - inset * 2f).coerceAtLeast(1f),
                        )

                        drawArc(
                            color = trackColor,
                            startAngle = -90f,
                            sweepAngle = 360f,
                            useCenter = false,
                            topLeft = Offset(inset, inset),
                            size = arcSize,
                            style = Stroke(width = baseStroke),
                        )

                        var startAngle = -90f
                        val gapDeg = if (slices.size > 1) 2.5f else 0f
                        slices.forEach { slice ->
                            val rawSweep = (slice.percentage / 100f) * 360f * sweepProgress
                            val effectiveSweep = (rawSweep - gapDeg).coerceAtLeast(2f)
                            val isSelected = slice.category == activeSlice?.category
                            drawArc(
                                color = sliceColors[slice.category] ?: Color.Gray,
                                startAngle = startAngle,
                                sweepAngle = effectiveSweep,
                                useCenter = false,
                                topLeft = Offset(inset, inset),
                                size = arcSize,
                                style = Stroke(
                                    width = if (isSelected) selectedStroke else baseStroke,
                                    cap = StrokeCap.Butt,
                                ),
                            )
                            startAngle += rawSweep
                        }
                    }

                    // Center KPI inside Donut
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(horizontal = 24.dp),
                    ) {
                        if (activeSlice != null) {
                            Text(
                                text = "${activeSlice.count}",
                                style = MaterialTheme.typography.headlineSmall.copy(fontFamily = MonoFontFamily),
                                fontWeight = FontWeight.ExtraBold,
                                color = sliceColors[activeSlice.category] ?: MaterialTheme.colorScheme.primary,
                            )
                            Text(
                                text = "${activeSlice.percentage.roundToInt()}%",
                                style = MaterialTheme.typography.labelMedium.copy(fontFamily = MonoFontFamily),
                                fontWeight = FontWeight.Bold,
                            )
                            Text(
                                text = categoryLabel(activeSlice.category, weeklyStrings),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                }
            }

            val breakdownListContent: @Composable (Modifier) -> Unit = { listModifier ->
                Column(
                    modifier = listModifier,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    slices.forEach { slice ->
                        CategorySliceRow(
                            slice = slice,
                            color = sliceColors[slice.category] ?: MaterialTheme.colorScheme.primary,
                            isSelected = slice.category == activeSlice?.category,
                            weeklyStrings = weeklyStrings,
                            onSelect = { onSelectCategory(slice.category) },
                            onOpenShield = { onFocusShield(slice.category.targetShield) },
                        )
                    }
                }
            }

            if (useSideBySide) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    donutContent()
                    breakdownListContent(Modifier.weight(1f))
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    donutContent()
                    breakdownListContent(Modifier.fillMaxWidth())
                }
            }
        }

        Text(
            text = weeklyStrings.tapSliceHint,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun CategorySliceRow(
    slice: CategoryBreakdownSlice,
    color: Color,
    isSelected: Boolean,
    weeklyStrings: WeeklyStatsStrings,
    onSelect: () -> Unit,
    onOpenShield: () -> Unit,
) {
    val label = categoryLabel(slice.category, weeklyStrings)
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (isSelected) {
            color.copy(alpha = 0.12f)
        } else {
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        },
        border = if (isSelected) BorderStroke(1.dp, color.copy(alpha = 0.55f)) else null,
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onSelect)
            .testTag("weekly_category_row_${slice.category.name}"),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(color.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = categoryIcon(slice.category),
                    contentDescription = label,
                    tint = color,
                    modifier = Modifier.size(18.dp),
                )
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = LocalizationManager.formatString(
                            weeklyStrings.categoryShareFormat,
                            slice.count,
                            slice.percentage.roundToInt(),
                        ),
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                        fontWeight = FontWeight.Bold,
                        color = color,
                    )
                }
                LinearProgressIndicator(
                    progress = { (slice.percentage / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(50)),
                    color = color,
                    trackColor = MaterialTheme.colorScheme.surface,
                )
            }
            IconButton(
                onClick = onOpenShield,
                modifier = Modifier
                    .size(48.dp)
                    .semantics { contentDescription = label }
                    .testTag("weekly_category_open_shield_${slice.category.name}"),
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = label,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp),
                )
            }
        }
    }
}

@Composable
private fun WeeklyInsightsFooter(
    summary: WeeklyThreatSummary,
    weeklyStrings: WeeklyStatsStrings,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        summary.topCategory?.let { topCat ->
            Surface(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            ) {
                Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                    Text(
                        text = weeklyStrings.topCategoryLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        text = categoryLabel(topCat, weeklyStrings),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        summary.peakDay?.let { peak ->
            Surface(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            ) {
                Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                    Text(
                        text = weeklyStrings.peakDayLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        text = "${peak.dayLabelShort} (${peak.totalCount})",
                        style = MaterialTheme.typography.labelLarge.copy(fontFamily = MonoFontFamily),
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}

@Composable
private fun categoryColor(category: PhishingCategory): Color {
    val dera3Colors = LocalDera3Colors.current
    val isLight = MaterialTheme.colorScheme.background.red > 0.5f
    return when (category) {
        PhishingCategory.LINK_PHISHING -> MaterialTheme.colorScheme.primary
        PhishingCategory.BANK_IMPERSONATION -> dera3Colors.danger
        PhishingCategory.FAKE_APP -> dera3Colors.caution
        PhishingCategory.OTP_SCAM -> if (isLight) VioletThreatDark else VioletThreat
        PhishingCategory.SMS_DELIVERY -> dera3Colors.safe
    }
}

private fun categoryIcon(category: PhishingCategory): ImageVector = when (category) {
    PhishingCategory.LINK_PHISHING -> Icons.Filled.Link
    PhishingCategory.BANK_IMPERSONATION -> Icons.AutoMirrored.Filled.PhoneMissed
    PhishingCategory.FAKE_APP -> Icons.Filled.AppBlocking
    PhishingCategory.OTP_SCAM -> Icons.Filled.Security
    PhishingCategory.SMS_DELIVERY -> Icons.Filled.SmsFailed
}

private fun categoryLabel(
    category: PhishingCategory,
    weeklyStrings: WeeklyStatsStrings,
): String = when (category) {
    PhishingCategory.LINK_PHISHING -> weeklyStrings.catLinkPhishing
    PhishingCategory.BANK_IMPERSONATION -> weeklyStrings.catBankImpersonation
    PhishingCategory.FAKE_APP -> weeklyStrings.catFakeApp
    PhishingCategory.OTP_SCAM -> weeklyStrings.catOtpScam
    PhishingCategory.SMS_DELIVERY -> weeklyStrings.catSmsDelivery
}
