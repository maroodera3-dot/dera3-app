package com.example

import android.content.Context
import android.os.Looper
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertTextEquals
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.test.core.app.ApplicationProvider
import com.example.data.preferences.PreferencesRepository
import com.example.localization.AppLanguage
import com.example.localization.LocalStrings
import com.example.localization.LocalizationManager
import com.example.localization.ProvideDera3Localization
import com.example.ui.components.SettingsLanguageSwitcherCard
import com.example.ui.theme.Dera3Theme
import java.util.Locale
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SettingsLanguageSwitcherTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun `settings language switcher updates locale resources layout direction and persists to datastore`() {
        val appContext = ApplicationProvider.getApplicationContext<Context>()
        val prefsRepository = PreferencesRepository(appContext)
        runBlocking {
            prefsRepository.setLanguage(AppLanguage.AR)
        }

        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        try {
            val localizationManager = LocalizationManager(prefsRepository, scope, appContext)
            var observedLayoutDirection: LayoutDirection? = null

            composeTestRule.setContent {
                val locState by localizationManager.state.collectAsStateWithLifecycle()
                ProvideDera3Localization(localizationManager = localizationManager) {
                    Dera3Theme(darkTheme = false) {
                        val strings = LocalStrings.current
                        val ctx = LocalContext.current
                        observedLayoutDirection = LocalLayoutDirection.current
                        Column {
                            SettingsLanguageSwitcherCard(
                                currentLanguage = locState.language,
                                onSelectLanguage = localizationManager::setLanguage,
                            )
                            Text(
                                text = "${strings.settingsTitle}|${ctx.getString(R.string.app_tagline)}",
                                modifier = Modifier.testTag("settings_localized_probe"),
                            )
                        }
                    }
                }
            }

            composeTestRule.waitForIdle()
            composeTestRule.onNodeWithTag("settings_language_switcher_card").assertIsDisplayed()
            composeTestRule.onNodeWithTag("settings_language_active_locale").assertTextEquals("ar-EG • RTL")
            composeTestRule.onNodeWithTag("settings_localized_probe").assertTextEquals("الإعدادات والحماية|درعك الرقمي")
            assertEquals(LayoutDirection.Rtl, observedLayoutDirection)
            assertEquals("ar", Locale.getDefault().language)

            // Switch to English in Settings
            composeTestRule.onNodeWithTag("settings_lang_en").performClick()
            composeTestRule.waitUntil(timeoutMillis = 5_000L) {
                Shadows.shadowOf(Looper.getMainLooper()).idle()
                localizationManager.currentLanguage == AppLanguage.EN
            }
            composeTestRule.waitForIdle()

            composeTestRule.onNodeWithTag("settings_language_active_locale").assertTextEquals("en-US • LTR")
            composeTestRule.onNodeWithTag("settings_localized_probe").assertTextEquals("Settings & Alerts|Your Digital Shield")
            assertEquals(LayoutDirection.Ltr, observedLayoutDirection)
            assertEquals("en", Locale.getDefault().language)
            assertEquals(AppLanguage.EN, runBlocking { prefsRepository.preferencesFlow.first().language })

            // Verify a newly created LocalizationManager restores the persisted EN preference
            val restoredManager = LocalizationManager(prefsRepository, scope, appContext)
            composeTestRule.waitUntil(timeoutMillis = 5_000L) {
                Shadows.shadowOf(Looper.getMainLooper()).idle()
                restoredManager.currentLanguage == AppLanguage.EN
            }
            assertEquals(AppLanguage.EN, restoredManager.currentLanguage)
            assertEquals("Settings & Alerts", restoredManager.currentStrings.settingsTitle)

            // Switch back to Arabic in Settings
            composeTestRule.onNodeWithTag("settings_lang_ar").performClick()
            composeTestRule.waitUntil(timeoutMillis = 5_000L) {
                Shadows.shadowOf(Looper.getMainLooper()).idle()
                localizationManager.currentLanguage == AppLanguage.AR
            }
            composeTestRule.waitForIdle()

            composeTestRule.onNodeWithTag("settings_language_active_locale").assertTextEquals("ar-EG • RTL")
            composeTestRule.onNodeWithTag("settings_localized_probe").assertTextEquals("الإعدادات والحماية|درعك الرقمي")
            assertEquals(LayoutDirection.Rtl, observedLayoutDirection)
            assertEquals("ar", Locale.getDefault().language)
            assertEquals(AppLanguage.AR, runBlocking { prefsRepository.preferencesFlow.first().language })
        } finally {
            scope.cancel()
        }
    }
}
