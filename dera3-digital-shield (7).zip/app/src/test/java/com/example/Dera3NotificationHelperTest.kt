package com.example

import android.Manifest
import android.app.Application
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.IncidentActionTaken
import com.example.data.local.ThreatIncidentEntity
import com.example.data.model.PhishingCategory
import com.example.data.model.ShieldId
import com.example.data.model.ThreatSeverity
import com.example.localization.AppLanguage
import com.example.notifications.Dera3NotificationHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class Dera3NotificationHelperTest {

    @Test
    fun requiresRuntimeNotificationPermission_onlyOnAndroid13Plus() {
        assertFalse(Dera3NotificationHelper.requiresRuntimeNotificationPermission(Build.VERSION_CODES.S_V2))
        assertTrue(Dera3NotificationHelper.requiresRuntimeNotificationPermission(Build.VERSION_CODES.TIRAMISU))
        assertTrue(Dera3NotificationHelper.requiresRuntimeNotificationPermission(Build.VERSION_CODES.UPSIDE_DOWN_CAKE))
    }

    @Test
    fun shouldPromptForNotificationPermission_checksSdkPrefAndCurrentGrant() {
        assertTrue(
            Dera3NotificationHelper.shouldPromptForNotificationPermission(
                sdkInt = Build.VERSION_CODES.TIRAMISU,
                permissionGranted = false,
                notificationsEnabledPref = true,
            )
        )
        assertFalse(
            Dera3NotificationHelper.shouldPromptForNotificationPermission(
                sdkInt = Build.VERSION_CODES.TIRAMISU,
                permissionGranted = true,
                notificationsEnabledPref = true,
            )
        )
        assertFalse(
            Dera3NotificationHelper.shouldPromptForNotificationPermission(
                sdkInt = Build.VERSION_CODES.TIRAMISU,
                permissionGranted = false,
                notificationsEnabledPref = false,
            )
        )
        assertFalse(
            Dera3NotificationHelper.shouldPromptForNotificationPermission(
                sdkInt = Build.VERSION_CODES.S,
                permissionGranted = false,
                notificationsEnabledPref = true,
            )
        )
    }

    @Test
    fun formatNotificationBody_combinesMessageAndIndicatorCleanly() {
        assertEquals(
            "Warning message\nhttp://bit.ly/scam",
            Dera3NotificationHelper.formatNotificationBody("Warning message", "http://bit.ly/scam"),
        )
        assertEquals(
            "Warning message",
            Dera3NotificationHelper.formatNotificationBody("Warning message", "   "),
        )
        assertEquals(
            "http://bit.ly/scam",
            Dera3NotificationHelper.formatNotificationBody("", "http://bit.ly/scam"),
        )
    }

    @Test
    fun notificationPriorityFor_mapsThreatSeverityAccurately() {
        assertEquals(
            NotificationCompat.PRIORITY_HIGH,
            Dera3NotificationHelper.notificationPriorityFor(ThreatSeverity.CRITICAL),
        )
        assertEquals(
            NotificationCompat.PRIORITY_HIGH,
            Dera3NotificationHelper.notificationPriorityFor(ThreatSeverity.HIGH),
        )
        assertEquals(
            NotificationCompat.PRIORITY_DEFAULT,
            Dera3NotificationHelper.notificationPriorityFor(ThreatSeverity.MEDIUM),
        )
    }

    @Test
    fun buildRoomIncidentLaunchIntent_targetsMainActivityWithRoomIncidentExtras() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val launchIntent = Dera3NotificationHelper.buildRoomIncidentLaunchIntent(context, 42L)

        assertEquals(MainActivity::class.java.name, launchIntent.component?.className)
        assertTrue(launchIntent.getBooleanExtra(Dera3NotificationHelper.EXTRA_OPEN_THREAT_HISTORY, false))
        assertEquals(42L, launchIntent.getLongExtra(Dera3NotificationHelper.EXTRA_THREAT_INCIDENT_ID, -1L))
        assertFalse(launchIntent.getBooleanExtra(Dera3NotificationHelper.EXTRA_OPEN_ALERTS_SHEET, true))
    }

    @Test
    fun showRoomThreatIncidentNotification_postsNotificationLinkedToRoomIncident() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        Shadows.shadowOf(app).grantPermissions(Manifest.permission.POST_NOTIFICATIONS)
        val notificationManager = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val shadowManager = Shadows.shadowOf(notificationManager)

        val incident = ThreatIncidentEntity(
            id = 77L,
            userId = "user_1",
            shieldKey = ShieldId.LINK_SCANNER.key,
            category = PhishingCategory.LINK_PHISHING.name,
            severity = ThreatSeverity.CRITICAL.name,
            indicator = "https://phish-dera3.example",
            titleAr = "تم رصد رابط تصيد خطر",
            titleEn = "Phishing Link Detected",
            messageAr = "تفاصيل الرابط الخبيث",
            messageEn = "Malicious phishing URL detected",
            actionTaken = IncidentActionTaken.DETECTED_LOGGED.name,
            resolved = false,
            detectedAtMillis = 1_700_002_000_000L,
        )

        val posted = Dera3NotificationHelper.showRoomThreatIncidentNotification(
            context = app,
            incident = incident,
            language = AppLanguage.EN,
        )
        assertTrue(posted)

        val active = shadowManager.allNotifications
        assertEquals(1, active.size)
        val postedNotif = active.first()
        assertEquals("Phishing Link Detected", postedNotif.extras.getString(NotificationCompat.EXTRA_TITLE))
        val pendingIntent = postedNotif.contentIntent
        assertNotNull(pendingIntent)

        val savedIntent = Shadows.shadowOf(pendingIntent).savedIntent
        assertTrue(savedIntent.getBooleanExtra(Dera3NotificationHelper.EXTRA_OPEN_THREAT_HISTORY, false))
        assertEquals(77L, savedIntent.getLongExtra(Dera3NotificationHelper.EXTRA_THREAT_INCIDENT_ID, -1L))
    }
}
