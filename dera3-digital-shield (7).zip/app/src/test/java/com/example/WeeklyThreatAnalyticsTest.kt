package com.example

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import com.example.data.model.PhishingCategory
import com.example.data.model.PhishingNotificationItem
import com.example.data.model.ShieldId
import com.example.data.model.ThreatSeverity
import com.example.data.model.UiState
import com.example.domain.WeeklyThreatAggregator
import com.example.localization.AppLanguage
import com.example.localization.ArabicStrings
import com.example.localization.LocalStrings
import com.example.ui.components.WeeklyThreatStatsDashboard
import com.example.ui.theme.Dera3Theme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.TimeZone

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class WeeklyThreatAnalyticsTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private fun itemAt(
        id: String,
        timestampSeconds: Long,
        category: PhishingCategory,
        severity: ThreatSeverity,
        read: Boolean = false,
        dismissed: Boolean = false,
    ) = PhishingNotificationItem(
        id = id,
        isPersonalDetection = true,
        titleAr = "تنبيه",
        titleEn = "Alert",
        messageAr = "رسالة",
        messageEn = "Message",
        category = category,
        severity = severity,
        indicator = id,
        targetShield = category.targetShield,
        read = read,
        dismissed = dismissed,
        timestampSeconds = timestampSeconds,
    )

    @Test
    fun `buildWeeklySummary buckets last 7 days and excludes older threats`() {
        val utc = TimeZone.getTimeZone("UTC")
        // 2026-11-23 12:00:00 UTC -> day start 2026-11-23 00:00:00 UTC
        val nowMillis = 1795435200_000L
        val todayNoonSec = nowMillis / 1000L
        val oneDaySec = 86_400L

        val items = listOf(
            itemAt("today_crit", todayNoonSec, PhishingCategory.OTP_SCAM, ThreatSeverity.CRITICAL, read = true),
            itemAt("today_high", todayNoonSec - 600L, PhishingCategory.LINK_PHISHING, ThreatSeverity.HIGH, read = false),
            itemAt("yesterday_med", todayNoonSec - oneDaySec, PhishingCategory.BANK_IMPERSONATION, ThreatSeverity.MEDIUM, dismissed = true),
            itemAt("six_days_ago", todayNoonSec - 6 * oneDaySec, PhishingCategory.LINK_PHISHING, ThreatSeverity.HIGH, read = true),
            // 8 days ago -> outside 7-day window
            itemAt("too_old", todayNoonSec - 8 * oneDaySec, PhishingCategory.FAKE_APP, ThreatSeverity.CRITICAL, read = false),
        )

        val summary = WeeklyThreatAggregator.buildWeeklySummary(
            items = items,
            nowMillis = nowMillis,
            language = AppLanguage.EN,
            timeZone = utc,
        )

        assertEquals(7, summary.dailyBuckets.size)
        assertEquals(4, summary.totalThreats)
        assertEquals(1, summary.criticalCount)
        assertEquals(2, summary.highCount)
        assertEquals(1, summary.mediumCount)
        assertEquals(3, summary.handledCount)
        assertEquals(1, summary.activeUnresolvedCount)
        assertEquals(75, summary.resolutionRatePercent)
        assertEquals(PhishingCategory.LINK_PHISHING, summary.topCategory)
        assertEquals(6, summary.peakDay?.dayIndex)
        assertEquals(2, summary.dailyBuckets[6].totalCount)
        assertEquals(1, summary.dailyBuckets[5].totalCount)
        assertEquals(1, summary.dailyBuckets[0].totalCount)
        assertEquals(50f, summary.categoryBreakdown.first().percentage, 0.01f)
    }

    @Test
    fun `buildWeeklySummary handles empty list cleanly`() {
        val summary = WeeklyThreatAggregator.buildWeeklySummary(
            items = emptyList(),
            nowMillis = 1795435200_000L,
            language = AppLanguage.AR,
            timeZone = TimeZone.getTimeZone("UTC"),
        )

        assertEquals(0, summary.totalThreats)
        assertEquals(7, summary.dailyBuckets.size)
        assertTrue(summary.categoryBreakdown.isEmpty())
        assertNull(summary.topCategory)
        assertNull(summary.peakDay)
        assertEquals(100, summary.resolutionRatePercent)
    }

    @Test
    fun `buildSamplePreviewItems covers all 5 categories across 7 days`() {
        val nowMillis = 1795435200_000L
        val sampleItems = WeeklyThreatAggregator.buildSamplePreviewItems(nowMillis)
        val summary = WeeklyThreatAggregator.buildWeeklySummary(
            items = sampleItems,
            nowMillis = nowMillis,
            language = AppLanguage.AR,
            isSamplePreview = true,
        )

        assertTrue(summary.isUsingSamplePreview)
        assertEquals(sampleItems.size, summary.totalThreats)
        assertEquals(5, summary.categoryBreakdown.size)
        assertTrue(summary.dailyBuckets.all { it.totalCount > 0 })
    }

    @Test
    fun `dashboard shows empty state then toggles to sample preview and category donut`() {
        var focusedShield: ShieldId? = null
        composeTestRule.setContent {
            Dera3Theme(darkTheme = false) {
                CompositionLocalProvider(LocalStrings provides ArabicStrings) {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                        WeeklyThreatStatsDashboard(
                            phishingNotificationsState = UiState.Success(emptyList()),
                            language = AppLanguage.AR,
                            onFocusShield = { focusedShield = it },
                        )
                    }
                }
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("weekly_threat_stats_card").assertExists()
        composeTestRule.onNodeWithTag("weekly_stats_empty_state").performScrollTo().assertIsDisplayed()

        // Enable sample preview from empty state CTA
        composeTestRule.onNodeWithTag("weekly_stats_empty_preview_btn").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("weekly_stats_sample_banner").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("weekly_stacked_bar_canvas").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("weekly_day_tooltip_card").performScrollTo().assertIsDisplayed()

        // Switch to Categories Donut chart
        composeTestRule.onNodeWithTag("weekly_stats_tab_categories").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("weekly_category_donut_canvas").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("weekly_category_row_${PhishingCategory.LINK_PHISHING.name}").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("weekly_category_open_shield_${PhishingCategory.LINK_PHISHING.name}").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        assertEquals(ShieldId.LINK_SCANNER, focusedShield)

        // Switch back to Live Data
        composeTestRule.onNodeWithTag("weekly_stats_live_chip").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithText(ArabicStrings.weeklyStats.chartEmptyTitle).performScrollTo().assertIsDisplayed()
    }
}
