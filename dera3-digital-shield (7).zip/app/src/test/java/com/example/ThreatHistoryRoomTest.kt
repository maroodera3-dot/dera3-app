package com.example

import android.content.Context
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.Dera3LocalDatabase
import com.example.data.local.IncidentActionTaken
import com.example.data.local.ThreatHistoryRepository
import com.example.data.local.ThreatIncidentEntity
import com.example.data.model.PhishingCategory
import com.example.data.model.PhishingNotificationItem
import com.example.data.model.ShieldId
import com.example.data.model.ThreatSeverity
import com.example.localization.AppLanguage
import com.example.localization.EnglishStrings
import com.example.localization.LocalStrings
import com.example.ui.components.ThreatHistoryBottomSheet
import com.example.ui.components.ThreatHistorySummaryCard
import com.example.ui.theme.Dera3Theme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ThreatHistoryRoomTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    private lateinit var db: Dera3LocalDatabase
    private lateinit var repository: ThreatHistoryRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, Dera3LocalDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = ThreatHistoryRepository(db.threatIncidentDao())
    }

    @After
    fun teardown() {
        db.close()
    }

    @Test
    fun `room repository records detected threats and tracks actions taken`() = runBlocking {
        val userId = "uid_room_1"

        val linkId = repository.recordDetectedIncident(
            userId = userId,
            shieldKey = ShieldId.LINK_SCANNER.key,
            category = PhishingCategory.LINK_PHISHING,
            severity = ThreatSeverity.CRITICAL,
            indicator = "https://bad-phish.example",
            titleAr = "رابط تصيد",
            titleEn = "Phishing Link",
            messageAr = "تفاصيل الرابط",
            messageEn = "Link details",
            detectedAtMillis = 1_700_000_000_000L,
        )
        val browserId = repository.recordDetectedIncident(
            userId = userId,
            shieldKey = ShieldId.SAFE_BROWSER.key,
            category = PhishingCategory.LINK_PHISHING,
            severity = ThreatSeverity.HIGH,
            indicator = "https://scam-browser.example",
            titleAr = "حظر المتصفح",
            titleEn = "Browser Blocked",
            messageAr = "تم المنع",
            messageEn = "Blocked",
            detectedAtMillis = 1_700_000_060_000L,
        )

        var list = repository.observeHistory(userId).first()
        assertEquals(2, list.size)
        // Ordered newest first
        assertEquals(browserId, list[0].id)
        assertEquals(IncidentActionTaken.BLOCKED_AUTO, list[0].parsedAction)
        assertTrue(list[0].resolved)

        assertEquals(linkId, list[1].id)
        assertEquals(IncidentActionTaken.DETECTED_LOGGED, list[1].parsedAction)
        assertFalse(list[1].resolved)

        // Update action to SHIELD_SECURED
        repository.updateActionTaken(linkId, IncidentActionTaken.SHIELD_SECURED)
        list = repository.observeHistory(userId).first()
        val updatedLink = list.first { it.id == linkId }
        assertEquals(IncidentActionTaken.SHIELD_SECURED, updatedLink.parsedAction)
        assertTrue(updatedLink.resolved)

        // Delete one incident and clear remainder
        repository.deleteIncident(browserId)
        assertEquals(1, repository.observeHistory(userId).first().size)

        repository.clearHistoryForUser(userId)
        assertTrue(repository.observeHistory(userId).first().isEmpty())
    }

    @Test
    fun `recordNotificationAction upserts by sourceKey without duplicates`() = runBlocking {
        val userId = "uid_room_2"
        val alertItem = PhishingNotificationItem(
            id = "global_alert_99",
            isPersonalDetection = false,
            titleAr = "تنبيه بنكي",
            titleEn = "Bank Alert",
            messageAr = "رسالة",
            messageEn = "Message",
            category = PhishingCategory.BANK_IMPERSONATION,
            severity = ThreatSeverity.CRITICAL,
            indicator = "+2010000000",
            targetShield = ShieldId.SCAM_CALLS,
            read = false,
            dismissed = false,
            timestampSeconds = 1_700_001_000L,
        )

        repository.recordNotificationAction(userId, alertItem, read = true, dismissed = false)
        var list = repository.observeHistory(userId).first()
        assertEquals(1, list.size)
        assertEquals(IncidentActionTaken.USER_INSPECTED, list[0].parsedAction)

        // Dismissing same alert updates existing entry instead of duplicating
        repository.recordNotificationAction(userId, alertItem, read = true, dismissed = true)
        list = repository.observeHistory(userId).first()
        assertEquals(1, list.size)
        assertEquals(IncidentActionTaken.USER_DISMISSED, list[0].parsedAction)
    }

    @Test
    fun `summary card and bottom sheet display incidents filters and actions`() {
        val pendingIncident = ThreatIncidentEntity(
            id = 10L,
            userId = "u1",
            shieldKey = ShieldId.LINK_SCANNER.key,
            category = PhishingCategory.LINK_PHISHING.name,
            severity = ThreatSeverity.CRITICAL.name,
            indicator = "https://verify-login.example",
            titleAr = "رابط تصيد",
            titleEn = "Phishing Link Detected",
            messageAr = "رسالة",
            messageEn = "Blocked suspicious URL",
            actionTaken = IncidentActionTaken.DETECTED_LOGGED.name,
            actionNoteEn = "Threat detected and logged locally",
            resolved = false,
            detectedAtMillis = 1_700_000_000_000L,
        )
        val resolvedIncident = ThreatIncidentEntity(
            id = 11L,
            userId = "u1",
            shieldKey = ShieldId.SAFE_BROWSER.key,
            category = PhishingCategory.LINK_PHISHING.name,
            severity = ThreatSeverity.HIGH.name,
            indicator = "https://fake-bank.example",
            titleAr = "المتصفح الآمن",
            titleEn = "Safe Browser Blocked URL",
            messageAr = "حظر",
            messageEn = "Auto blocked",
            actionTaken = IncidentActionTaken.BLOCKED_AUTO.name,
            actionNoteEn = "Automatically blocked by Safe Browser",
            resolved = true,
            detectedAtMillis = 1_700_001_000_000L,
        )

        var openedSheet by mutableStateOf(false)
        var securedTarget: ShieldId? = null
        var updatedPair: Pair<Long, IncidentActionTaken>? = null

        composeTestRule.setContent {
            Dera3Theme(darkTheme = false) {
                CompositionLocalProvider(LocalStrings provides EnglishStrings) {
                    if (!openedSheet) {
                        Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                            ThreatHistorySummaryCard(
                                incidents = listOf(resolvedIncident, pendingIncident),
                                language = AppLanguage.EN,
                                onOpenFullHistory = { openedSheet = true },
                            )
                        }
                    } else {
                        ThreatHistoryBottomSheet(
                            incidents = listOf(resolvedIncident, pendingIncident),
                            language = AppLanguage.EN,
                            readOnly = false,
                            onDismiss = { openedSheet = false },
                            onUpdateAction = { id, action -> updatedPair = id to action },
                            onSecureShield = { _, shield -> securedTarget = shield },
                            onDeleteIncident = {},
                            onClearHistory = {},
                        )
                    }
                }
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("local_threat_history_card").assertExists()
        composeTestRule.onNodeWithTag("local_history_preview_11").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("open_local_threat_history_button").performScrollTo().performClick()
        composeTestRule.waitForIdle()

        // Filter to Pending and trigger Mark Inspected + Secure Shield
        composeTestRule.onNodeWithTag("threat_history_filter_pending").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("threat_incident_item_10").assertIsDisplayed()
        composeTestRule.onNodeWithTag("incident_mark_inspected_10").performClick()
        composeTestRule.waitForIdle()
        assertEquals(10L to IncidentActionTaken.USER_INSPECTED, updatedPair)

        composeTestRule.onNodeWithTag("incident_secure_shield_10").performClick()
        composeTestRule.waitForIdle()
        assertEquals(ShieldId.LINK_SCANNER, securedTarget)
    }

    @Test
    fun `room lookup by id and highlighted incident card display notification details immediately`() = runBlocking {
        val userId = "uid_room_highlight"
        val insertedEntity = repository.recordDetectedIncidentEntity(
            userId = userId,
            shieldKey = ShieldId.SCAM_CALLS.key,
            category = PhishingCategory.BANK_IMPERSONATION,
            severity = ThreatSeverity.CRITICAL,
            indicator = "+201555000999",
            titleAr = "مكالمة احتيال بنكي",
            titleEn = "Bank Impersonation Call",
            messageAr = "المتصل طلب رمز التحقق",
            messageEn = "Caller requested banking OTP",
            detectedAtMillis = 1_700_005_000_000L,
        )
        assertTrue(insertedEntity.id > 0L)
        val fetched = repository.getIncidentById(insertedEntity.id)
        assertEquals(insertedEntity.id, fetched?.id)
        assertEquals("+201555000999", fetched?.indicator)

        var actionUpdate: Pair<Long, IncidentActionTaken>? = null
        composeTestRule.setContent {
            Dera3Theme(darkTheme = false) {
                CompositionLocalProvider(LocalStrings provides EnglishStrings) {
                    ThreatHistoryBottomSheet(
                        incidents = listOf(insertedEntity),
                        language = AppLanguage.EN,
                        readOnly = false,
                        onDismiss = {},
                        onUpdateAction = { id, act -> actionUpdate = id to act },
                        onSecureShield = { _, _ -> },
                        onDeleteIncident = {},
                        onClearHistory = {},
                        highlightedIncidentId = insertedEntity.id,
                    )
                }
            }
        }

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("highlighted_incident_detail_card").assertIsDisplayed()
        composeTestRule.onNodeWithTag("highlighted_incident_mark_inspected").performScrollTo().performClick()
        composeTestRule.waitForIdle()
        assertEquals(insertedEntity.id to IncidentActionTaken.USER_INSPECTED, actionUpdate)
    }
}
