package com.example

import android.app.Activity
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.NoCredentialException
import androidx.test.core.app.ApplicationProvider
import com.example.localization.AppLanguage
import com.example.localization.ArabicStrings
import com.example.localization.Dera3StringResources
import com.example.localization.EnglishStrings
import com.example.ui.auth.findActivity
import com.example.ui.auth.onGoogleSignInClicked
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.firebase.FirebaseApp
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.lang.reflect.Proxy
import kotlin.coroutines.Continuation
import kotlin.coroutines.intrinsics.COROUTINE_SUSPENDED

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AuthHelperRobolectricTest {

    @Test
    fun `findActivity unwraps nested LocalizedContextWrapper to host Activity`() {
        val appContext = ApplicationProvider.getApplicationContext<Context>()
        assertNull(appContext.findActivity())

        val activity = Robolectric.buildActivity(ComponentActivity::class.java).create().get()
        val arContext = Dera3StringResources.localizedContext(activity, AppLanguage.AR)
        val enContext = Dera3StringResources.localizedContext(arContext, AppLanguage.EN)

        assertSame(activity, arContext.findActivity())
        assertSame(activity, enContext.findActivity())
    }

    @Test
    fun `onGoogleSignInClicked reports error when context has no Activity`() {
        val appContext = ApplicationProvider.getApplicationContext<Context>()
        val wrappedAppContext = Dera3StringResources.localizedContext(appContext, AppLanguage.AR)
        val credentialManager = fakeCredentialManager { _, _ ->
            Result.failure(AssertionError("CredentialManager should not be called without Activity"))
        }

        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        try {
            var errorText: String? = null
            onGoogleSignInClicked(
                context = wrappedAppContext,
                credentialManager = credentialManager,
                onAuthSuccess = {},
                onAuthError = { errorText = it },
                scope = scope,
                signInFailedMessage = "Sign in failed",
            )
            assertEquals("Sign in failed", errorText)
        } finally {
            scope.cancel()
        }
    }

    @Test
    fun `onGoogleSignInClicked unwraps LocalizedContextWrapper and tries fallback on NoCredentialException`() = runBlocking {
        val activity = Robolectric.buildActivity(ComponentActivity::class.java).create().get()
        if (FirebaseApp.getApps(activity).isEmpty()) {
            FirebaseApp.initializeApp(activity)
        }
        val wrappedActivity = Dera3StringResources.localizedContext(activity, AppLanguage.AR)

        val capturedContexts = mutableListOf<Context>()
        val capturedRequests = mutableListOf<GetCredentialRequest>()

        val credentialManager = fakeCredentialManager { ctx, req ->
            capturedContexts.add(ctx)
            capturedRequests.add(req)
            Result.failure(NoCredentialException("No credentials on test device"))
        }

        val errorDeferred = CompletableDeferred<String>()
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        try {
            val arStrings = Dera3StringResources.load(activity, AppLanguage.AR)
            onGoogleSignInClicked(
                context = wrappedActivity,
                credentialManager = credentialManager,
                onAuthSuccess = {},
                onAuthError = { errorDeferred.complete(it) },
                scope = scope,
                configMissingMessage = arStrings.authConfigMissingError,
                unexpectedCredentialMessage = arStrings.authUnexpectedCredentialError,
                signInFailedMessage = arStrings.authSignInFailedError,
                noCredentialMessage = arStrings.authNoCredentialError,
            )

            shadowOf(android.os.Looper.getMainLooper()).idle()
            val errorMessage = withTimeout(5_000L) { errorDeferred.await() }

            assertEquals(arStrings.authNoCredentialError, errorMessage)
            assertEquals(2, capturedContexts.size)
            assertSame(activity, capturedContexts[0])
            assertSame(activity, capturedContexts[1])
            assertEquals(1, capturedRequests[0].credentialOptions.size)
            assertTrue(capturedRequests[0].credentialOptions[0] is GetSignInWithGoogleOption)
            assertEquals(1, capturedRequests[1].credentialOptions.size)
            assertTrue(capturedRequests[1].credentialOptions[0] is GetGoogleIdOption)
            val fallbackOption = capturedRequests[1].credentialOptions[0] as GetGoogleIdOption
            assertEquals(false, fallbackOption.filterByAuthorizedAccounts)
        } finally {
            scope.cancel()
        }
    }

    @Test
    fun `onGoogleSignInClicked notifies cancellation when user dismisses prompt`() = runBlocking {
        val activity = Robolectric.buildActivity(ComponentActivity::class.java).create().get()
        if (FirebaseApp.getApps(activity).isEmpty()) {
            FirebaseApp.initializeApp(activity)
        }
        val wrappedActivity = Dera3StringResources.localizedContext(activity, AppLanguage.EN)

        val credentialManager = fakeCredentialManager { _, _ ->
            Result.failure(GetCredentialCancellationException("User cancelled"))
        }

        val cancelledDeferred = CompletableDeferred<Boolean>()
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        try {
            onGoogleSignInClicked(
                context = wrappedActivity,
                credentialManager = credentialManager,
                onAuthSuccess = {},
                onAuthError = { error("Unexpected error callback: $it") },
                onAuthCancelled = { cancelledDeferred.complete(true) },
                scope = scope,
            )

            shadowOf(android.os.Looper.getMainLooper()).idle()
            assertTrue(withTimeout(5_000L) { cancelledDeferred.await() })
        } finally {
            scope.cancel()
        }
    }

    @Test
    fun `localized no-credential strings are present in Arabic and English`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val ar = Dera3StringResources.load(context, AppLanguage.AR)
        val en = Dera3StringResources.load(context, AppLanguage.EN)

        assertEquals(ArabicStrings.authNoCredentialError, ar.authNoCredentialError)
        assertEquals(EnglishStrings.authNoCredentialError, en.authNoCredentialError)
        assertTrue(ar.authNoCredentialError.isNotBlank())
        assertTrue(en.authNoCredentialError.isNotBlank())
    }

    @Suppress("UNCHECKED_CAST")
    private fun fakeCredentialManager(
        handler: (Context, GetCredentialRequest) -> Result<Any>,
    ): CredentialManager {
        return Proxy.newProxyInstance(
            CredentialManager::class.java.classLoader,
            arrayOf(CredentialManager::class.java),
        ) { _, method, args ->
            if (method.name == "getCredential" && args != null && args.size == 3) {
                val ctx = args[0] as Context
                val req = args[1] as GetCredentialRequest
                val cont = args[2] as Continuation<Any>
                cont.resumeWith(handler(ctx, req))
                COROUTINE_SUSPENDED
            } else {
                throw UnsupportedOperationException("Unexpected call to ${method.name}")
            }
        } as CredentialManager
    }
}
